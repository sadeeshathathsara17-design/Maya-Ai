package com.maya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == android.content.pm.PackageManager.PERMISSION_GRANTED)
            startForegroundService(Intent(this, MayaService::class.java).putExtra("greet", true))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 48) }
        fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        l.gravity = android.view.Gravity.CENTER_HORIZONTAL
        val sz = (300 * resources.displayMetrics.density).toInt()
        l.addView(ImageView(this).apply {
            setImageResource(R.drawable.maya_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER   // logo එක සම්පූර්ණයෙන්ම පෙනෙනවා
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(sz, sz))
        l.addView(TextView(this).apply { text = "\"මායා\" කියලා කතා කරන්න"; textSize = 18f; gravity = android.view.Gravity.CENTER })
        btn("1. මයික් සහ notification අවසරය දෙන්න") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Accessibility සක්‍රිය කරන්න (Maya)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. Battery optimization අක්‍රිය කරන්න") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("4. Notification access දෙන්න (මැසේජ් කියවීමට)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("5. සිංහල කටහඬ (Text-to-speech) සැකසුම්") { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
        btn("6. Maya පටන් ගන්න") { startForegroundService(Intent(this, MayaService::class.java).putExtra("greet", true)) }
        btn("Maya නවත්වන්න") { stopService(Intent(this, MayaService::class.java)) }
        setContentView(l)
        // Maya open වුණාම ඉබේම පටන් අරන් "Welcome Sir" කියනවා
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED)
            startForegroundService(Intent(this, MayaService::class.java).putExtra("greet", true))
    }
}
