package com.maya.assistant

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** WhatsApp / SMS / Gmail වගේ notifications අල්ලගන්නවා (මැසේජ් කියවන්න) */
class MayaNotificationListener : NotificationListenerService() {
    data class Msg(val app: String, val title: String, val text: String, var read: Boolean = false)

    companion object {
        val inbox: MutableList<Msg> = java.util.Collections.synchronizedList(ArrayList())
        @Volatile var onNew: ((Msg) -> Unit)? = null
        @Volatile var connected = false
    }

    override fun onListenerConnected() { connected = true }
    override fun onListenerDisconnected() { connected = false }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val cat = n.category
        if (cat != null && cat != Notification.CATEGORY_MESSAGE && cat != Notification.CATEGORY_EMAIL &&
            cat != Notification.CATEGORY_SOCIAL) return
        val e = n.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim() ?: return
        if (text.isEmpty()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        synchronized(inbox) {
            val last = inbox.lastOrNull()
            if (last != null && last.title == title && last.text == text) return
            inbox.add(Msg(app, title, text))
            if (inbox.size > 30) inbox.removeAt(0)
        }
        onNew?.invoke(inbox.last())
    }
}
