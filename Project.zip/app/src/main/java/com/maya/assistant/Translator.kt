package com.maya.assistant

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** ඕනෑම භාෂාවකින් (English ඇතුළුව) සිංහලට පරිවර්තනය. Internet ඕනේ. අසාර්ථක නම් null */
object Translator {
    fun toSinhala(text: String, cb: (String?) -> Unit) {
        Thread {
            val out = try {
                val u = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=si&dt=t&q=" +
                    URLEncoder.encode(text.take(900), "UTF-8"))
                val c = u.openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("User-Agent", "Mozilla/5.0")
                val arr = JSONArray(c.inputStream.bufferedReader().readText()).getJSONArray(0)
                buildString { for (i in 0 until arr.length()) append(arr.getJSONArray(i).getString(0)) }
            } catch (_: Exception) { null }
            Handler(Looper.getMainLooper()).post { cb(out) }
        }.start()
    }
}
