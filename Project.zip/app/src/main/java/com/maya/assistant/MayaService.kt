package com.maya.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class MayaService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private lateinit var sr: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private val h = Handler(Looper.getMainLooper())
    private var awakeUntil = 0L
    @Volatile private var speaking = false
    private var ignoreUntil = 0L
    private var autoRead = false

    private val wake = listOf("maya", "maaya", "මායා", "මයා", "මාය")
    private val YT = "com.google.android.youtube"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "maya"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Maya", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch)
            .setContentTitle("Maya අහගෙන ඉන්නවා").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        tts = TextToSpeech(this, this)
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(this)
        MayaNotificationListener.onNew = { m ->
            h.post {
                if (autoRead && MayaAccessibility.inst?.scrolling != true) { m.read = true; readSeq(listOf(m), 0) }
            }
        }
        listen()
    }

    override fun onInit(s: Int) {
        val r = tts.setLanguage(Locale("si", "LK"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            showNotif("සිංහල කටහඬ නෑ. Settings > Text-to-speech > Google එකේ Sinhala install කරන්න")
        ttsReady = true
        if (pendingGreet) { pendingGreet = false; h.post { greet(true) } }
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true }
            override fun onDone(id: String?) { speaking = false; ignoreUntil = SystemClock.elapsedRealtime() + 1200 }
            @Deprecated("x") override fun onError(id: String?) { speaking = false }
        })
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.getBooleanExtra("greet", false) == true) h.post { greet(true) }
        return START_STICKY
    }
    override fun onDestroy() { sr.destroy(); tts.shutdown(); MayaNotificationListener.onNew = null; super.onDestroy() }

    private fun listen() = h.postDelayed({
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "si-LK")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        try { sr.startListening(i) } catch (_: Exception) { listen() }
    }, 250)

    override fun onResults(b: Bundle?) {
        val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (text != null) handle(text.lowercase())
        listen()
    }
    override fun onError(e: Int) { listen() }
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {
        MayaAccessibility.inst?.orb?.let { it.level = maxOf(it.level, ((v + 2f) / 12f).coerceIn(0f, 1f)) }
    }
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(b: Bundle?) {}
    override fun onEvent(t: Int, b: Bundle?) {}

    private val hideRun = Runnable { MayaAccessibility.inst?.hideOrb() }
    private fun orbOn(ms: Long) { MayaAccessibility.inst?.showOrb(); h.removeCallbacks(hideRun); h.postDelayed(hideRun, ms) }

    // scroll වෙනකොට කතා කළොත් audio focus අරන් video නවතිනවා, ඒ නිසා නිහඬයි
    private fun say(s: String) {
        if (MayaAccessibility.inst?.scrolling == true) return
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "m")
    }
    private fun sayForce(s: String) { tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "m") }

    private fun showNotif(t: String) {
        getSystemService(NotificationManager::class.java).notify(System.currentTimeMillis().toInt(),
            Notification.Builder(this, "maya").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Maya").setContentText(t)
                .setStyle(Notification.BigTextStyle().bigText(t)).setAutoCancel(true).build())
    }

    /** නොකියවපු මැසේජ් (උපරිම 3ක්) සිංහලට පරිවර්තනය කරලා කියවනවා */
    private fun readUnread() {
        if (!MayaNotificationListener.connected) { sayForce("Notification access සක්‍රිය කරන්න"); return }
        val unread = synchronized(MayaNotificationListener.inbox) {
            MayaNotificationListener.inbox.filter { !it.read }.takeLast(3)
        }
        if (unread.isEmpty()) { sayForce("අලුත් මැසේජ් නෑ"); return }
        unread.forEach { it.read = true }
        readSeq(unread, 0)
    }

    private fun readSeq(list: List<MayaNotificationListener.Msg>, i: Int) {
        if (i >= list.size) return
        val m = list[i]
        Translator.toSinhala(m.text) { si ->
            val line = if (si == null) "${m.app} එකෙන් ${m.title} ගෙන් මැසේජ් එකක් ආවා. පරිවර්තනය කරන්න බැරි වුණා, internet බලන්න"
                       else "${m.app} එකෙන් ${m.title} ගෙන්: $si"
            showNotif(line)
            tts.speak(line, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "m")
            readSeq(list, i + 1)
        }
    }

    private fun handle(raw: String) {
        if (speaking || SystemClock.elapsedRealtime() < ignoreUntil) return   // මගේ කටහඬ ආපහු අහගන්න එපා
        var cmd = raw
        val heard = wake.any { cmd.contains(it) }
        if (heard) { wake.forEach { cmd = cmd.replace(it, "") }; awakeUntil = SystemClock.elapsedRealtime() + 25000; orbOn(25000) }
        if (SystemClock.elapsedRealtime() > awakeUntil) return   // wake word නැතුව ignore
        cmd = cmd.trim()
        if (cmd.isEmpty()) { greet(false); return }
        extendSession()                       // තව command දෙන්න තත්පර 25ක් අහගෙන ඉන්නවා
        runChain(splitCmds(cmd), 0)           // කියපු පිළිවෙලටම එකින් එක කරනවා
    }

    private fun exec(cmd: String) {
        val acc = MayaAccessibility.inst
        val words = cmd.split(" ")
        fun w(vararg k: String) = k.any { it in words }
        fun has(vararg k: String) = k.any { cmd.contains(it) }

        when {
            has("ස්තූතියි", "thanks", "thank", "bye", "ඉවරයි", "එච්චරයි", "ගිහින්") -> {
                awakeUntil = 0; h.removeCallbacks(hideRun); h.postDelayed(hideRun, 600); say("හරි Sir")
            }
            has("ඉබේම", "ඔටෝ", "auto") && has("කියවන්න", "කියවපන්", "read", "මැසේජ්", "ඊමේල්", "message") -> {
                autoRead = !has("නවත්ත", "off", "ඕෆ්", "අක්‍රිය")
                sayForce(if (autoRead) "අලුත් මැසේජ් ඉබේම කියවනවා" else "ඉබේම කියවීම නැවැත්තුවා")
            }
            has("close", "ක්ලෝස්", "ක්ලොස්", "වහන්න", "වහපන්", "වහල", "වසන්න", "වසා", "වහලා") -> {
                if (acc == null) say("Accessibility on කරන්න") else { say("ඔකේ"); acc.closeCurrentApp() }
            }
            has("stop", "නවත්ත", "නවත්ව", "නවතින්න", "ස්ටොප්", "ස්ටෝප්") -> { acc?.stopScroll(); say("නැවැත්තුවා") }
            has("තත්පර", "seconds", "second") && Regex("\\d+").containsMatchIn(cmd) -> {
                val n = Regex("\\d+").find(cmd)!!.value.toLong().coerceIn(1, 60)
                acc?.intervalMs = n * 1000; say("තත්පර $n කට වරක් scroll කරනවා")
            }
            has("fast", "faster", "speed", "වේගය වැඩි", "වේගවත්", "වේගෙන්", "ඉක්මන්", "ෆාස්ට්", "ඉක්මනට") -> { acc?.faster(); say("වේගය වැඩි කළා") }
            has("slow", "ස්ලෝ", "හෙමින්", "හෙමිහිට", "වේගය අඩු", "අඩු කරන්න") -> { acc?.slower(); say("වේගය අඩු කළා") }
            has("search", "සර්ච්", "සර්ච", "හොයන්න", "හොයපන්", "හොයල", "සොයන්න", "සොයා", "සෙවීම") -> {
                val filler = setOf("search", "සර්ච්", "සර්ච", "හොයන්න", "හොයපන්", "හොයල", "සොයන්න", "සොයා", "සෙවීම",
                    "karanna", "කරන්න", "කරපන්", "youtube", "යූටියුබ්", "යුටියුබ්", "ටියුබ්", "යූ", "යු",
                    "එකේ", "එකෙන්", "එක", "ekema", "eke", "දාන්න", "පෙන්නන්න")
                val q = cmd.split(" ").filter { it.isNotBlank() && it !in filler }.joinToString(" ").trim()
                if (q.isEmpty()) { awakeUntil = SystemClock.elapsedRealtime() + 8000; orbOn(8000); say("මොකක්ද හොයන්න ඕනේ") }
                else { searchYouTube(q); say("$q හොයනවා") }
            }
            (w("up", "previous", "back", "down", "next") ||
                has("උඩට", "ඉහළට", "කලින්", "පහළට", "ඊළඟ", "ඊලඟ")) -> {
                if (acc == null) say("Accessibility on කරන්න") else {
                    val up = w("up", "previous", "back") || has("උඩට", "ඉහළට", "කලින්")
                    if (has("scroll", "ස්ක්‍රෝල්", "ස්ක්රෝල්", "ඉබේම", "auto") || acc.scrolling) {
                        acc.dir = if (up) -1 else 1; acc.startScroll()
                    } else if (up) acc.prev() else acc.next()
                }
            }
            has("short", "scroll", "ෂෝට්ස්", "ෂෝර්ට්ස්", "ෂෝට්", "ෂෝර්ට්", "ශෝට්", "ස්ක්‍රෝල්", "ස්ක්රෝල්") -> {
                open(Uri.parse("https://www.youtube.com/shorts"), YT)
                if (acc == null) say("Accessibility on කරන්න") else {
                    acc.stopScroll(); acc.dir = 1; h.postDelayed({ acc.startScroll() }, 3500); say("ෂෝර්ට්ස් scroll කරනවා")
                }
            }
            has("youtube", "යූටියුබ්", "යුටියුබ්", "යූ ටියුබ්", "යු ටියුබ්", "ටියුබ්") -> { launchPackage(YT); say("යූටියුබ් open කළා") }
            has("open", "ඕපන්", "ඇරපන්", "අරපන්", "ඇරන්න", "අරින්න", "විවෘත", "ඇරලා") -> openByName(cmd)
            has("කියවන්න", "කියවපන්", "කියවල", "read", "මැසේජ්", "මැසේජස්", "මැසේජ", "මෙසේජ්", "ඊමේල්", "ඊ මේල්",
                "email", "message", "පණිවිඩ", "නොටිෆිකේෂන්") -> readUnread()
        }
    }

    private var ttsReady = false
    private var pendingGreet = false

    private fun extendSession() { awakeUntil = SystemClock.elapsedRealtime() + 25000; orbOn(25000) }

    /** "Welcome Sir" කියලා මොනවද කරන්න ඕනේ කියලා අහනවා. ඊට පස්සේ command අහගෙන ඉන්නවා */
    private fun greet(force: Boolean) {
        if (!ttsReady) { pendingGreet = true; return }
        extendSession()
        val t = "Welcome Sir, මම ඔයාට මොනවද කරන්න ඕනේ?"
        if (force) sayForce(t) else say(t)
    }

    private val splitter = Regex("\\s+(?:ඊට\\s?පස්සේ|ඊටපස්සේ|ඉන්\\s?පස්සේ|ඊළඟට|ඊලඟට|ඊට පස්සෙ|then|and|සහ|කරලා|කරල)\\s+|[,.،]")
    private fun splitCmds(c: String) = c.split(splitter).map { it.trim() }.filter { it.isNotEmpty() }

    private fun runChain(parts: List<String>, i: Int) {
        if (i >= parts.size) return
        val p = parts[i]
        exec(p)
        val slow = listOf("open", "ඕපන්", "ඇරපන්", "අරපන්", "ඇරන්න", "අරින්න", "විවෘත", "ඇරලා", "search", "සර්ච්",
            "හොයන්න", "හොයපන්", "close", "ක්ලෝස්", "වහන්න", "වහපන්", "short", "ෂෝට්ස්", "ෂෝර්ට්ස්",
            "youtube", "යූටියුබ්", "යුටියුබ්").any { p.contains(it) }
        h.postDelayed({ runChain(parts, i + 1) }, if (slow) 4000L else 900L)
    }

    private fun searchYouTube(q: String) {
        val i = Intent(Intent.ACTION_SEARCH).setPackage(YT)
            .putExtra("query", q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (_: Exception) {
            open(Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)), null)
        }
    }

    private fun open(u: Uri, pkg: String?) {
        val i = Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.setPackage(pkg)
        try { startActivity(i) } catch (_: Exception) {}
    }

    private fun launchPackage(p: String) {
        packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private val alias = mapOf(
        "වට්ස්ඇප්" to "whatsapp", "වට්සැප්" to "whatsapp", "ව්ට්ස්ඇප්" to "whatsapp",
        "ෆේස්බුක්" to "facebook", "ෆේස්බුක්" to "facebook", "මැසෙන්ජර්" to "messenger",
        "ටික්ටොක්" to "tiktok", "ටික්ටොක්" to "tiktok", "ඉන්ස්ටග්‍රෑම්" to "instagram", "ඉන්ස්ටාග්‍රෑම්" to "instagram",
        "ටෙලිග්‍රෑම්" to "telegram", "කැමරා" to "camera", "කැමරාව" to "camera", "ගැලරි" to "gallery",
        "ෆොටෝස්" to "photos", "සෙටින්ස්" to "settings", "සැකසුම්" to "settings", "ක්‍රෝම්" to "chrome",
        "ගූගල්" to "google", "ෆෝන්" to "phone", "දුරකථන" to "phone", "මැසේජ්" to "messages",
        "මැසේජස්" to "messages", "කැල්කියුලේටර්" to "calculator", "ඔරලෝසුව" to "clock", "ක්ලොක්" to "clock",
        "මැප්ස්" to "maps", "සිතියම" to "maps", "ස්පොටිෆයි" to "spotify", "නෙට්ෆ්ලික්ස්" to "netflix",
        "ජීමේල්" to "gmail", "ඩ්‍රයිව්" to "drive", "ප්ලේ ස්ටෝර්" to "play store", "ප්ලේස්ටෝර්" to "play store",
        "කොන්ටැක්ට්ස්" to "contacts", "කැලැන්ඩර්" to "calendar", "ෆයිල්ස්" to "files", "ස්නැප්චැට්" to "snapchat")

    /** "open whatsapp" / "වට්ස්ඇප් ඕපන් කරන්න" වගේ ඕනෑම app එකක් නමින් open කරනවා */
    private fun openByName(cmd: String) {
        val filler = setOf("open", "ඕපන්", "ඇරපන්", "අරපන්", "ඇරන්න", "අරින්න", "විවෘත", "ඇරලා", "දෙන්න",
            "කරන්න", "කරපන්", "karanna", "එක", "එකක්", "app", "ඇප්", "ඇප්එක")
        var n = cmd.split(" ").filter { it.isNotBlank() && it !in filler }.joinToString(" ").trim()
        n = alias[n] ?: alias[n.replace(" ", "")] ?: n
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(n) && pm.getLaunchIntentForPackage(it.packageName) != null
        }
        if (n.isNotEmpty() && app != null) { launchPackage(app.packageName); say("open කළා") } else say("app එක හොයාගන්න බැරි වුණා")
    }
}
