package com.maya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 48) }
        fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        l.gravity = android.view.Gravity.CENTER_HORIZONTAL
        val sz = (300 * resources.displayMetrics.density).toInt()
        l.addView(ImageView(this).apply {
            setImageResource(R.drawable.maya_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER   // logo එක සම්පූර්ණයෙන්ම පෙනෙනවා
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(sz, sz))
        l.addView(TextView(this).apply { text = "Wake word: \"Maya\""; textSize = 18f; gravity = android.view.Gravity.CENTER })
        btn("1. Mic + Notification permission") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Accessibility on කරන්න (Maya)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. Battery optimization off") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("4. Maya start") { startForegroundService(Intent(this, MayaService::class.java)) }
        btn("Maya stop") { stopService(Intent(this, MayaService::class.java)) }
        setContentView(l)
    }
}
