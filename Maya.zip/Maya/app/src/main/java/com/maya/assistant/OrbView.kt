package com.maya.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

/** Siri වගේ glowing animated orb. කතා කරනකොට voice level එකට pulse වෙනවා */
class OrbView(c: Context) : View(c) {
    @Volatile var level = 0f
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cols = intArrayOf(0x2979FF, 0x7C4DFF, 0x00E5FF)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; level *= 0.93f; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = width * 0.2f * (1f + 0.3f * level)
        p.xfermode = null
        p.shader = RadialGradient(cx, cy, r * 2.4f, intArrayOf(0x662979FF, 0x00000000), null, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r * 2.4f, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
        for (i in 0..2) {
            val a = (t * 2 * Math.PI + i * 2.094).toFloat()
            val ox = cos(a) * r * 0.4f; val oy = sin(a * 1.3f) * r * 0.4f
            p.shader = RadialGradient(cx + ox, cy + oy, r,
                intArrayOf(0xCC000000.toInt() or cols[i], cols[i]), null, Shader.TileMode.CLAMP)
            cv.drawCircle(cx + ox, cy + oy, r, p)
        }
        p.shader = null; p.xfermode = null
    }
}
