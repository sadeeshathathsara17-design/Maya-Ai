package com.maya.assistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class MayaService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private lateinit var sr: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private val h = Handler(Looper.getMainLooper())
    private var awakeUntil = 0L

    private val wake = listOf("maya", "maaya", "මායා", "මයා", "මාය")
    private val YT = "com.google.android.youtube"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "maya"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Maya", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch)
            .setContentTitle("Maya අහගෙන ඉන්නවා").setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        tts = TextToSpeech(this, this)
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(this)
        listen()
    }

    override fun onInit(s: Int) { tts.language = Locale("si", "LK") }
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onDestroy() { sr.destroy(); tts.shutdown(); super.onDestroy() }

    private fun listen() = h.postDelayed({
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "si-LK")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        try { sr.startListening(i) } catch (_: Exception) { listen() }
    }, 250)

    override fun onResults(b: Bundle?) {
        val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (text != null) handle(text.lowercase())
        listen()
    }
    override fun onError(e: Int) { listen() }
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {
        MayaAccessibility.inst?.orb?.let { it.level = maxOf(it.level, ((v + 2f) / 12f).coerceIn(0f, 1f)) }
    }
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(b: Bundle?) {}
    override fun onEvent(t: Int, b: Bundle?) {}

    private val hideRun = Runnable { MayaAccessibility.inst?.hideOrb() }
    private fun orbOn(ms: Long) { MayaAccessibility.inst?.showOrb(); h.removeCallbacks(hideRun); h.postDelayed(hideRun, ms) }

    // scroll වෙනකොට කතා කළොත් audio focus අරන් video නවතිනවා, ඒ නිසා නිහඬයි
    private fun say(s: String) {
        if (MayaAccessibility.inst?.scrolling == true) return
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "m")
    }

    private fun handle(raw: String) {
        var cmd = raw
        val heard = wake.any { cmd.contains(it) }
        if (heard) { wake.forEach { cmd = cmd.replace(it, "") }; awakeUntil = SystemClock.elapsedRealtime() + 8000; orbOn(8000) }
        if (SystemClock.elapsedRealtime() > awakeUntil) return   // wake word නැතුව ignore
        cmd = cmd.trim()
        if (cmd.isEmpty()) { say("ඔව්"); return }
        awakeUntil = 0
        h.removeCallbacks(hideRun); h.postDelayed(hideRun, 1500)   // command එක කළාම orb එක විතරක් off
        val acc = MayaAccessibility.inst
        fun has(vararg k: String) = k.any { cmd.contains(it) }

        when {
            has("close", "ක්ලෝස්", "වහන්න", "වහපන්", "වහල") -> {
                if (acc == null) say("Accessibility on කරන්න") else { say("ඔකේ"); acc.closeCurrentApp() }
            }
            has("stop", "නවත්ත", "නවත්ව", "ස්ටොප්") -> { acc?.stopScroll(); say("නැවැත්තුවා") }
            has("fast", "faster", "වේගය වැඩි", "ඉක්මන්", "speed") -> { acc?.faster(); say("වේගය වැඩි කළා") }
            has("slow", "හෙමින්", "වේගය අඩු") -> { acc?.slower(); say("වේගය අඩු කළා") }
            has("search", "සර්ච්", "හොයන්න", "හොයපන්", "සොයන්න") -> {
                var q = cmd
                listOf("search", "සර්ච්", "හොයන්න", "හොයපන්", "සොයන්න", "karanna", "කරන්න", "youtube",
                    "යූටියුබ්", "යුටියුබ්", "එකේ", "ekema", "eke").forEach { q = q.replace(it, "") }
                q = q.trim()
                if (q.isEmpty()) { awakeUntil = SystemClock.elapsedRealtime() + 8000; orbOn(8000); say("මොකක්ද හොයන්න ඕනේ") }
                else { searchYouTube(q); say("$q හොයනවා") }
            }
            has("short", "ෂෝට්ස්", "ෂෝර්ට්", "scroll", "ස්ක්‍රෝල්") -> {
                open(Uri.parse("https://www.youtube.com/shorts"), YT)
                if (acc == null) say("Accessibility on කරන්න") else {
                    acc.stopScroll(); h.postDelayed({ acc.startScroll() }, 3500); say("ෂෝර්ට්ස් scroll කරනවා")
                }
            }
            has("youtube", "යූටියුබ්", "යුටියුබ්") -> { launchPackage(YT); say("යූටියුබ් open කළා") }
            has("open", "ඕපන්", "ඇරපන්", "අරින්න") -> openByName(cmd)
        }
    }

    private fun searchYouTube(q: String) {
        val i = Intent(Intent.ACTION_SEARCH).setPackage(YT)
            .putExtra("query", q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (_: Exception) {
            open(Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)), null)
        }
    }

    private fun open(u: Uri, pkg: String?) {
        val i = Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.setPackage(pkg)
        try { startActivity(i) } catch (_: Exception) {}
    }

    private fun launchPackage(p: String) {
        packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    /** "open whatsapp" වගේ ඕනෑම app එකක් නමින් open කරනවා */
    private fun openByName(cmd: String) {
        var n = cmd
        listOf("open", "ඕපන්", "ඇරපන්", "අරින්න", "කරන්න", "karanna").forEach { n = n.replace(it, "") }
        n = n.trim()
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(n) && pm.getLaunchIntentForPackage(it.packageName) != null
        }
        if (n.isNotEmpty() && app != null) { launchPackage(app.packageName); say("open කළා") } else say("app එක හොයාගන්න බැරි වුණා")
    }
}
