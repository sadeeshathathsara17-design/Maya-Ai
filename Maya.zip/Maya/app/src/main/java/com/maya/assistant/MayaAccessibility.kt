package com.maya.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.graphics.PixelFormat
import android.view.accessibility.AccessibilityEvent

class MayaAccessibility : AccessibilityService() {
    companion object { var inst: MayaAccessibility? = null }

    private val h = Handler(Looper.getMainLooper())
    var scrolling = false
    var intervalMs = 4000L   // shorts එකක් බලන කාලය (වේගය)

    private val loop = object : Runnable {
        override fun run() {
            if (!scrolling) return
            swipe(0.75f, 0.25f, 80)          // TikTok වගේ fast flick
            h.postDelayed(this, intervalMs)
        }
    }

    var orb: OrbView? = null

    /** NOT_FOCUSABLE + NOT_TOUCHABLE => video pause වෙන්නෙත් නෑ, scroll gesture එකට බාධාවකුත් නෑ */
    fun showOrb() {
        if (orb != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val sz = (260 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(sz, sz, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = 40 }
        val v = OrbView(this)
        try { wm.addView(v, lp); orb = v } catch (_: Exception) {}
    }

    fun hideOrb() {
        val v = orb ?: return
        orb = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) {}
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun swipe(fromY: Float, toY: Float, dur: Long) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val p = Path().apply { moveTo(x, m.heightPixels * fromY); lineTo(x, m.heightPixels * toY) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build(), null, null)
    }

    fun startScroll() { if (!scrolling) { scrolling = true; h.postDelayed(loop, intervalMs) } }
    fun stopScroll() { scrolling = false; h.removeCallbacks(loop) }
    fun faster() { intervalMs = (intervalMs / 1.6).toLong().coerceAtLeast(1000) }
    fun slower() { intervalMs = (intervalMs * 1.6).toLong().coerceAtMost(15000) }

    /** දැන් open තියෙන app එක recents වලින් swipe කරලා close කරනවා */
    fun closeCurrentApp() {
        stopScroll()
        performGlobalAction(GLOBAL_ACTION_RECENTS)
        h.postDelayed({ swipe(0.55f, 0.08f, 150) }, 900)
        h.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 1500)
    }
}
