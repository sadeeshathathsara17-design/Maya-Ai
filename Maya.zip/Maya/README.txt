Android Studio -> New Project (Empty Views Activity, package com.maya.assistant, Kotlin)
එකේ app/src/main ඇතුළේ මේ files replace කරන්න (AndroidManifest.xml, res/xml, java/com/maya/assistant).
Run කරලා app එකේ බටන් 1-4 පිළිවෙළට ඔබන්න.

Voice commands (පළමුව "Maya" කියන්න):
 "Maya YouTube"            -> YouTube open
 "Maya cat videos search"   -> YouTube search
 "Maya shorts"              -> Shorts open + auto scroll
 "Maya fast / slow"         -> scroll speed
 "Maya stop"                -> scroll නවත්තනවා
 "Maya close"               -> app close (recents swipe)
 "Maya open whatsapp"       -> ඕනෑම app එකක් open
