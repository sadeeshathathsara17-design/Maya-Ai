# Maya AI (Android)
Voice assistant app: Sinhala/English speech, open & close apps, calls, SMS, alarms, weather.
The screen (app/src/main/assets/index.html) runs inside a WebView and talks to the phone through the `Android` JavaScript bridge (MainActivity.java).
Phone-wide control (Back/Home, close apps, tap, scroll) needs the Accessibility service switched on once.
Always-on "Maya" wake word: WakeService.java uses Vosk (offline, free);
Build: push to GitHub; the workflow in .github/workflows/build.yml produces Maya-AI.apk under Releases.

## What's new (speed + search in any app + Siri mode)
- **Faster:** the mic stops listening 0.7 s after you stop talking, and the phone-control steps poll every 0.12 s (was 0.35 s).
- **Search in ANY app:** "Spotify eke Kamal play karanna", "Play Store eke X hoyanna", "search X on Netflix". Maya opens the app, types in its search bar, presses search and (for play requests) opens the first result. YouTube keeps its own faster path.
- **Contacts:** "Amal ta call ekak ganna" / "Amal ta whatsapp eke hello kiyala message ekak danna". Partial names work (first name only).
- **Siri mode:** Profile > "Set Maya as default assistant". Then long-press the power button or swipe from a bottom corner: the orb pops up over any app.
