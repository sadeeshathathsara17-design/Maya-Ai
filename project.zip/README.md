# Maya AI (Android)
Voice assistant app: Sinhala/English speech, open & close apps, calls, SMS, alarms, weather.
The screen (app/src/main/assets/index.html) runs inside a WebView and talks to the phone through the `Android` JavaScript bridge (MainActivity.java).
Phone-wide control (Back/Home, close apps, tap, scroll) needs the Accessibility service switched on once.
Always-on "Maya" wake word: WakeService.java uses Vosk (offline, free);
Build: push to GitHub; the workflow in .github/workflows/build.yml produces Maya-AI.apk under Releases.

## What's new (speed + search in any app + Siri mode)
- **Faster:** the mic stops listening 0.7 s after you stop talking, and the phone-control steps poll every 0.12 s (was 0.35 s).
- **Search in ANY app:** "Spotify eke Kamal play karanna", "Play Store eke X hoyanna", "search X on Netflix". Maya opens the app, types in its search bar, presses search and (for play requests) opens the first result. YouTube keeps its own faster path.
- **Contacts:** "Amal ta call ekak ganna" / "Amal ta whatsapp eke hello kiyala message ekak danna". Partial names work (first name only).
- **Siri mode:** Profile > "Set Maya as default assistant". Then long-press the power button or swipe from a bottom corner: the orb pops up over any app.

## Smarter listening + natural voice
- Maya now gets up to 5 hearings from the speech recognizer and passes them (plus your phone contact names) to the AI, so mis-heard words/names are understood by meaning.
- Contact and app names are matched by similar spelling too ("Kamaal" finds "Kamal", "spotifi" opens Spotify).
- Voice: Maya picks the most natural female voice installed (prefers network/neural voices), speaks slightly higher and slower, sentence by sentence with small pauses.
  For the best sound: Settings > Languages > Text-to-speech > Google > install the high-quality (network) female voice.
- "What time is it?" / "වෙලාව කීයද?" / "ada mona dawasada?" are answered instantly on the phone.
- Wake word "Maya" also accepts close sounds (maia, mia, maja).

## Open Maya = talk right away
- The app icon / "Hey Google, open Maya" now opens the **orb** (Siri style) and listens immediately: no tiles to tap. (First run still opens the full app so you can enter the API key.)
- Full app screen: say "Maya settings", long-press the Maya icon > Maya settings, or Profile > "When I open Maya".
- After Maya opens another app (YouTube, WhatsApp...) the orb comes back over that app and keeps listening (needs "Display over other apps"), and stays for 30 s of silence.
- "scroll up" / "scroll down" (also "uda/pahalata", "උඩට/පහළට"): in Shorts / Reels / TikTok the video moves up/down on screen (up = next, down = previous). In other apps it scrolls normally.
- "tiktok eka open karanna", "whatsapp eka open karapan" etc. now work (the little "eka/එක" word is ignored).

## "One moment" hang fix
- Gemini: fastest model first (2.5 flash-lite) with thinking switched off, 15 s per try (was 60 s), max 5 tries. The "-latest" models think for 10+ s and were the cause of the long waits.
- Claude: 25 s timeout. The page gives up after 30 s with a message instead of staying on "One moment".

## Instant (no-AI) commands
Handled on the phone in well under a second: open/close app, close all apps, call, WhatsApp message, YouTube / in-app search, scroll up/down, next/previous video, back/home/recents/notifications/lock/screenshot, alarm ("alarm 6.30", "උදේ 6.30 ට alarm"), timer ("5 minute timer"), time and date. Anything else goes to the AI (about 1.5-3 s).
Mic now stops listening 0.55 s after you finish talking.

## Wake word is strict again
Only a finished phrase counts, "maya" must be its first or last word (phrase of at most 4 words) and Vosk must be at least 85% sure. Partial guesses and look-alike words (mia/maia/maja) no longer open the orb, so normal talking won't trigger it.

## Song requests, instantly
"සමනල වැව සින්දුව දාන්න", "samanala wewa song eka danna", "ගීතය ඇහුන්න ඕන" etc. open YouTube, search and play the first result with no AI round trip.
