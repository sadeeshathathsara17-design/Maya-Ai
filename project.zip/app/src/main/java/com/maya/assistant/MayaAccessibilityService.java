package com.maya.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/**
 * Lets Maya press Back/Home/Recents, scroll, tap on-screen text and close apps
 * (by opening the recent-apps screen and swiping the card away).
 * The user must switch this service on once in Android Settings > Accessibility.
 */
public class MayaAccessibilityService extends AccessibilityService {

    static volatile MayaAccessibilityService instance;

    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // not used
    }

    @Override
    public void onInterrupt() {
        // not used
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    /** Called from the JavaScript bridge (any thread). Returns "ok", "a11y_off", "notfound" or "unknown". */
    static String perform(final String action, final String arg) {
        final MayaAccessibilityService s = instance;
        if (s == null) {
            return "a11y_off";
        }
        if (action == null) {
            return "unknown";
        }
        switch (action) {
            case "back":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_BACK));
                return "ok";
            case "home":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_HOME));
                return "ok";
            case "recents":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_RECENTS));
                return "ok";
            case "notifications":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS));
                return "ok";
            case "quick_settings":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS));
                return "ok";
            case "lock":
                if (Build.VERSION.SDK_INT >= 28) {
                    s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN));
                }
                return "ok";
            case "screenshot":
                if (Build.VERSION.SDK_INT >= 28) {
                    s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT));
                }
                return "ok";
            case "scroll_down":
                s.main.post(() -> s.swipe(0.5f, 0.72f, 0.5f, 0.28f, 320));
                return "ok";
            case "scroll_up":
                s.main.post(() -> s.swipe(0.5f, 0.28f, 0.5f, 0.72f, 320));
                return "ok";
            case "tap":
                final boolean[] result = new boolean[1];
                final Object lock = new Object();
                s.main.post(() -> {
                    result[0] = s.tapText(arg);
                    synchronized (lock) {
                        lock.notifyAll();
                    }
                });
                synchronized (lock) {
                    try {
                        lock.wait(1500);
                    } catch (InterruptedException ignored) {
                        // fall through
                    }
                }
                return result[0] ? "ok" : "notfound";
            case "yt_play":
                s.main.post(s::autoPlayYoutube);
                return "ok";
            case "app_search":
                s.main.post(() -> s.autoSearch(arg, false));
                return "ok";
            case "app_search_play":
                s.main.post(() -> s.autoSearch(arg, true));
                return "ok";
            case "wa_send":
                s.main.post(s::autoSendWhatsApp);
                return "ok";
            case "close_current":
                s.main.post(s::closeCurrentApp);
                return "ok";
            case "close_all":
                s.main.post(s::closeAllApps);
                return "ok";
            default:
                return "unknown";
        }
    }

    private void swipe(float x1, float y1, float x2, float y2, long durationMs) {
        DisplayMetrics m = getResources().getDisplayMetrics();
        Path p = new Path();
        p.moveTo(m.widthPixels * x1, m.heightPixels * y1);
        p.lineTo(m.widthPixels * x2, m.heightPixels * y2);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, durationMs));
        dispatchGesture(b.build(), null, null);
    }

    /** Finds a visible node whose text/description contains the given text and clicks it (or its clickable parent). */
    private boolean tapText(String text) {
        if (text == null || text.trim().isEmpty()) {
            return false;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            return false;
        }
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(text);
        if (nodes == null) {
            return false;
        }
        for (AccessibilityNodeInfo n : nodes) {
            AccessibilityNodeInfo cur = n;
            int hops = 0;
            while (cur != null && hops < 8) {
                if (cur.isClickable() && cur.isEnabled()) {
                    if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true;
                    }
                }
                cur = cur.getParent();
                hops++;
            }
        }
        return false;
    }

    /** Opens the recent-apps screen, swipes the front card up (dismisses it), then goes Home. */
    private void closeCurrentApp() {
        performGlobalAction(GLOBAL_ACTION_RECENTS);
        main.postDelayed(() -> swipe(0.5f, 0.55f, 0.5f, 0.06f, 220), 650);
        main.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_HOME), 1200);
    }

    /** Opens recents and taps "Close all" / "Clear all", then goes Home. */
    private void closeAllApps() {
        performGlobalAction(GLOBAL_ACTION_RECENTS);
        main.postDelayed(() -> {
            String[] labels = {"Close all", "Clear all", "Close All", "Clear All", "CLOSE ALL", "CLEAR ALL"};
            for (String l : labels) {
                if (tapText(l)) {
                    break;
                }
            }
        }, 700);
        main.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_HOME), 1400);
    }

    // ------------------------------------------------------------------ automation helpers

    private interface NodeAction {
        boolean run(AccessibilityNodeInfo root, int attempt);
    }

    /** Polls the front window every 120 ms (up to timeoutMs) until action returns true. */
    private void pollUntil(final String pkgPrefix, final NodeAction action, final long timeoutMs) {
        final long end = SystemClock.uptimeMillis() + timeoutMs;
        final int[] n = {0};
        Runnable r = new Runnable() {
            @Override
            public void run() {
                boolean done = false;
                try {
                    AccessibilityNodeInfo root = getRootInActiveWindow();
                    if (root != null && root.getPackageName() != null
                            && root.getPackageName().toString().startsWith(pkgPrefix)) {
                        done = action.run(root, n[0]++);
                    }
                } catch (Exception ignored) {
                    // window changed while reading: try again
                }
                if (!done && SystemClock.uptimeMillis() < end) {
                    main.postDelayed(this, 120);
                }
            }
        };
        main.postDelayed(r, 150);
    }

    private static boolean clickNode(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur = node;
        for (int hops = 0; cur != null && hops < 8; hops++) {
            if (cur.isClickable() && cur.isEnabled() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }
            cur = cur.getParent();
        }
        return false;
    }

    /** text + content description of a node and its children (shallow), lower case. */
    private static String describe(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 4) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        if (n.getContentDescription() != null) {
            sb.append(n.getContentDescription()).append(' ');
        }
        if (n.getText() != null) {
            sb.append(n.getText()).append(' ');
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            sb.append(describe(n.getChild(i), depth + 1));
        }
        return sb.toString().toLowerCase(java.util.Locale.ROOT);
    }

    private static boolean looksLikeVideo(String d) {
        if (d.isEmpty() || d.contains("sponsored") || d.contains("shorts")) {
            return false;
        }
        return d.contains("play video") || (d.contains(" views") && d.contains(" ago")) || d.contains(" watching");
    }

    private static AccessibilityNodeInfo findVideoNode(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 28) {
            return null;
        }
        if (n.isClickable() && n.getContentDescription() != null
                && looksLikeVideo(n.getContentDescription().toString().toLowerCase(java.util.Locale.ROOT))) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo f = findVideoNode(n.getChild(i), depth + 1);
            if (f != null) {
                return f;
            }
        }
        return null;
    }

    /** After the YouTube search results open, taps the first real video so it starts playing. */
    private void autoPlayYoutube() {
        pollUntil("com.google.android.youtube", this::tryPlayYoutube, 9000);
    }

    private boolean tryPlayYoutube(AccessibilityNodeInfo root, int attempt) {
        List<AccessibilityNodeInfo> lists = root.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/results");
        if (lists != null) {
            for (AccessibilityNodeInfo list : lists) {
                for (int i = 0; i < list.getChildCount(); i++) {
                    AccessibilityNodeInfo child = list.getChild(i);
                    if (child != null && looksLikeVideo(describe(child, 0)) && clickNode(child)) {
                        return true;
                    }
                }
            }
        }
        AccessibilityNodeInfo v = findVideoNode(root, 0);
        if (v != null && clickNode(v)) {
            return true;
        }
        if (attempt == 45) { // ~6 s and nothing readable: tap where the first result normally is
            swipe(0.5f, 0.30f, 0.5f, 0.30f, 60);
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ search in ANY app

    private static boolean visible(AccessibilityNodeInfo n) {
        return n != null && n.isVisibleToUser();
    }

    /** First visible text field on screen (a focused one wins). */
    private static AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 30) {
            return null;
        }
        if (n.isEditable() && visible(n)) {
            return n;
        }
        AccessibilityNodeInfo found = null;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo f = findEditable(n.getChild(i), depth + 1);
            if (f != null) {
                if (f.isFocused()) {
                    return f;
                }
                if (found == null) {
                    found = f;
                }
            }
        }
        return found;
    }

    /** A clickable magnifier / "Search" button or bar (used to open the search field first). */
    private static AccessibilityNodeInfo findSearchIcon(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 30) {
            return null;
        }
        if (n.isClickable() && n.isEnabled() && visible(n) && !n.isEditable()) {
            String d = describe(n, 3);
            String id = n.getViewIdResourceName() == null ? "" : n.getViewIdResourceName().toLowerCase(java.util.Locale.ROOT);
            if (d.contains("search") || id.contains("search") || d.contains("සොයන්න") || d.contains("සෙවුම")) {
                return n;
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo f = findSearchIcon(n.getChild(i), depth + 1);
            if (f != null) {
                return f;
            }
        }
        return null;
    }

    /** Presses the keyboard's search/enter key for the field, else taps a visible "Search" button. */
    private boolean submitSearch(AccessibilityNodeInfo field, AccessibilityNodeInfo root) {
        if (Build.VERSION.SDK_INT >= 30
                && field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())) {
            return true;
        }
        String[] labels = {"Search", "Go", "සොයන්න"};
        for (String label : labels) {
            List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(label);
            if (l != null) {
                for (AccessibilityNodeInfo n : l) {
                    if (n != null && !n.isEditable() && clickNode(n)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** First big clickable row inside a scrolling list, below the search bar. */
    private static AccessibilityNodeInfo firstResult(AccessibilityNodeInfo n, int depth, int minTop, boolean inScroll) {
        if (n == null || depth > 30) {
            return null;
        }
        boolean scroll = inScroll || n.isScrollable();
        if (scroll && n.isClickable() && n.isEnabled() && visible(n) && !n.isEditable()) {
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            String d = describe(n, 0).trim();
            if (r.top >= minTop && r.height() > 90 && !d.isEmpty() && !d.contains("sponsored")) {
                return n;
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo f = firstResult(n.getChild(i), depth + 1, minTop, scroll);
            if (f != null) {
                return f;
            }
        }
        return null;
    }

    /**
     * Works in whatever app is in front (YouTube, Spotify, Play Store, Contacts, Gallery, ...):
     * finds the search bar (tapping the search icon first if needed), types the words, presses search
     * and, when play is true, opens the first result.
     */
    private void autoSearch(final String query, final boolean play) {
        final int[] stage = {0};
        final long[] t = {0, 0}; // [0] when the text was entered, [1] last time the search icon was tapped
        pollUntil("", (root, attempt) -> {
            String pkg = String.valueOf(root.getPackageName());
            if (pkg.equals(getPackageName()) || pkg.equals("com.android.systemui")) {
                return false; // the target app is not in front yet
            }
            if (stage[0] == 0) {
                AccessibilityNodeInfo field = findEditable(root, 0);
                if (field == null) {
                    long now = SystemClock.uptimeMillis();
                    if (now - t[1] > 800) {
                        AccessibilityNodeInfo icon = findSearchIcon(root, 0);
                        if (icon != null && clickNode(icon)) {
                            t[1] = now;
                        }
                    }
                    return false;
                }
                field.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                Bundle b = new Bundle();
                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, query);
                if (!field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) {
                    return false;
                }
                main.postDelayed(() -> {
                    AccessibilityNodeInfo r = getRootInActiveWindow();
                    AccessibilityNodeInfo f = r == null ? null : findEditable(r, 0);
                    if (f != null) {
                        submitSearch(f, r);
                    }
                }, 150);
                stage[0] = 1;
                t[0] = SystemClock.uptimeMillis();
                return !play;
            }
            // stage 1: results are loading, then open the first one
            if (SystemClock.uptimeMillis() - t[0] < 800) {
                return false;
            }
            if (pkg.startsWith("com.google.android.youtube")) {
                return tryPlayYoutube(root, attempt);
            }
            int minTop = (int) (getResources().getDisplayMetrics().heightPixels * 0.14f);
            AccessibilityNodeInfo field = findEditable(root, 0);
            if (field != null) {
                Rect fr = new Rect();
                field.getBoundsInScreen(fr);
                minTop = Math.max(minTop, fr.bottom);
            }
            AccessibilityNodeInfo res = firstResult(root, 0, minTop, false);
            return res != null && clickNode(res);
        }, 14000);
    }

    /** After a WhatsApp chat opens with the text filled in, presses the green Send button. */
    private void autoSendWhatsApp() {
        pollUntil("com.whatsapp", (root, attempt) -> {
            String[] ids = {"com.whatsapp:id/send", "com.whatsapp.w4b:id/send"};
            for (String id : ids) {
                List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId(id);
                if (l != null) {
                    for (AccessibilityNodeInfo n : l) {
                        if (clickNode(n)) {
                            return true;
                        }
                    }
                }
            }
            String[] labels = {"Send", "යවන්න"};
            for (String label : labels) {
                List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(label);
                if (l != null) {
                    for (AccessibilityNodeInfo n : l) {
                        CharSequence d = n.getContentDescription();
                        if (d != null && d.toString().equalsIgnoreCase(label) && clickNode(n)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }, 10000);
    }
}
