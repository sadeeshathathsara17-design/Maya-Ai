package com.maya.assistant;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

/**
 * The app icon / "Hey Google, open Maya". Instantly forwards to the Siri-style orb (listening right away,
 * nothing to tap) once the app is set up, otherwise to the full app so the API key can be entered.
 */
public class LauncherActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences p = getSharedPreferences(WakeService.PREFS, MODE_PRIVATE);
        boolean toOrb = p.getBoolean("siri_launch", true) && p.getBoolean("ready", false);
        Intent i = new Intent(this, toOrb ? SiriActivity.class : MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        if (toOrb) {
            i.putExtra("wake", true);
        }
        startActivity(i);
        finish();
        overridePendingTransition(0, 0);
    }
}
