package com.maya.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Hosts the Maya AI screen (assets/index.html) in a WebView and gives it real phone powers
 * through the JavaScript object "Android": speech in/out, open/close apps, calls, SMS,
 * alarms, contacts and (with the Accessibility service) taps, scrolling and Back/Home.
 */
public class MainActivity extends Activity {

    private static final Map<String, String> ALIASES = new HashMap<>();

    static {
        ALIASES.put("fb", "facebook");
        ALIASES.put("face book", "facebook");
        ALIASES.put("yt", "youtube");
        ALIASES.put("you tube", "youtube");
        ALIASES.put("whats app", "whatsapp");
        ALIASES.put("insta", "instagram");
        ALIASES.put("tik tok", "tiktok");
        ALIASES.put("google chrome", "chrome");
        ALIASES.put("play store", "play store");
    }

    private WebView web;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile boolean visible = false;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (!siriMode()) {
            getWindow().setStatusBarColor(0xFF030814);
            getWindow().setNavigationBarColor(0xFF030814);
        }

        web = new WebView(this);
        web.setBackgroundColor(siriMode() ? 0 : 0xFF030814);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");

        initTts();
        requestRuntimePermissions();
        handleWake(getIntent());
    }

    private volatile boolean wakePending = false;

    /** When this app last started another activity (used so the orb can come back over the app Maya just opened). */
    static volatile long lastAppLaunch = 0;
    /** Set when the orb is being closed on purpose (idle / "stop"), so it does not come back. */
    protected volatile boolean closing = false;

    @Override
    public void startActivity(Intent intent, Bundle options) {
        lastAppLaunch = SystemClock.uptimeMillis();
        super.startActivity(intent, options);
    }

    /** True in SiriActivity: only the orb is shown, at the bottom, over whatever app is on screen. */
    protected boolean siriMode() {
        return false;
    }

    /** Opened by the "Maya" wake word: show over the lock screen, and start listening. */
    private void handleWake(Intent intent) {
        if (intent == null || !intent.getBooleanExtra("wake", false)) {
            return;
        }
        intent.removeExtra("wake");
        wakePending = true;
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        js("window.__wake && window.__wake()");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleWake(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        WakeService.setAppVisible(true);
        js("window.__onResume && window.__onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        visible = false;
        if (recognizer != null) {
            recognizer.cancel();
        }
        WakeService.setAppVisible(false);
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
                "(function(){var s=document.querySelector('.view.sub.on');if(s){s.classList.remove('on');return 'closed';}return 'none';})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (value == null || !value.contains("closed")) {
                            MainActivity.super.onBackPressed();
                        }
                    }
                });
    }

    // ------------------------------------------------------------------ helpers

    private void js(final String code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(code, null);
                }
            }
        });
    }

    private boolean has(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestRuntimePermissions() {
        List<String> need = new ArrayList<>();
        String[] wanted = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.POST_NOTIFICATIONS
        };
        for (String p : wanted) {
            if (p.equals(Manifest.permission.POST_NOTIFICATIONS) && Build.VERSION.SDK_INT < 33) {
                continue;
            }
            if (!has(p)) {
                need.add(p);
            }
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), 1);
        }
    }

    private void initTts() {
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                ttsReady = (status == TextToSpeech.SUCCESS);
                if (ttsReady && tts != null) {
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override
                        public void onStart(String utteranceId) {
                        }

                        @Override
                        public void onDone(String utteranceId) {
                            if ("maya".equals(utteranceId)) {
                                js("window.__onSpeakDone && window.__onSpeakDone()");
                            }
                        }

                        @Override
                        public void onError(String utteranceId) {
                            if ("maya".equals(utteranceId)) {
                                js("window.__onSpeakDone && window.__onSpeakDone()");
                            }
                        }
                    });
                }
            }
        });
    }

    /** Female voice hints in Google TTS voice names (e.g. en-us-x-tpf-network). */
    private static final String[] FEMALE_HINTS = {"female", "-tpf", "-iog", "-iob", "-sfg", "-tpc", "-gba", "-ena", "-enb", "-hia"};

    /** Picks the most natural-sounding (network / high quality) female voice installed for this language. */
    private Voice bestVoice(Locale loc) {
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) {
                return null;
            }
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Voice v : all) {
                if (!v.getLocale().getLanguage().equals(loc.getLanguage())) {
                    continue;
                }
                int score = 0;
                String n = v.getName().toLowerCase(Locale.ROOT);
                if (v.getLocale().getCountry().equals(loc.getCountry())) {
                    score += 20;
                }
                for (String h : FEMALE_HINTS) {
                    if (n.contains(h)) {
                        score += 30;
                        break;
                    }
                }
                if (n.contains("male") && !n.contains("female")) {
                    score -= 40;
                }
                if (n.contains("network")) {
                    score += 15; // neural voices usually sound far more human
                }
                score += v.getQuality() / 100;
                if (v.getFeatures() != null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) {
                    score -= 100;
                }
                if (score > bestScore) {
                    bestScore = score;
                    best = v;
                }
            }
            return best;
        } catch (Exception e) {
            return null;
        }
    }

    private static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) {
            prev[j] = j;
        }
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }

    /** Similar spelling: allows about 1 wrong letter per 4 (so a mis-heard "Kamaal" still finds "Kamal"). */
    private static boolean closeEnough(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) {
            return false;
        }
        int limit = Math.max(1, Math.min(a.length(), b.length()) / 4);
        return lev(a, b) <= limit;
    }

    private static String norm(String s) {
        if (s == null) {
            return "";
        }
        return s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{M}\\p{N} ]", "").trim();
    }

    /** Finds an installed launchable app by (approximate) name. */
    private ResolveInfo findApp(String name) {
        String q = norm(name);
        // "tiktok eka", "whatsapp app", "ෆේස්බුක් එක": drop the little word on the end
        for (int k = 0; k < 2; k++) {
            q = q.replaceAll("\\s+(eka|ekak|app|\u0DD9\u0D9A|\u0D91\u0D9A|\u0D91\u0D9A\u0D9A\u0DCA|\u0D87\u0DB4\u0DCA)$", "").trim();
        }
        if (q.isEmpty()) {
            return null;
        }
        String alias = ALIASES.get(q);
        if (alias != null) {
            q = alias;
        }
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
        ResolveInfo exact = null;
        ResolveInfo starts = null;
        ResolveInfo contains = null;
        String compact = q.replace(" ", "");
        for (ResolveInfo ri : list) {
            String label = norm(String.valueOf(ri.loadLabel(pm)));
            String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
            if (label.equals(q)) {
                exact = ri;
                break;
            }
            if (starts == null && label.startsWith(q)) {
                starts = ri;
            }
            if (contains == null && (label.contains(q) || pkg.contains(compact))) {
                contains = ri;
            }
        }
        if (exact != null) {
            return exact;
        }
        if (starts != null) {
            return starts;
        }
        if (contains != null) {
            return contains;
        }
        // similar spelling ("spotifi", "youtub", "instagrm")
        ResolveInfo near = null;
        int nearDist = 99;
        for (ResolveInfo ri : list) {
            String label = norm(String.valueOf(ri.loadLabel(pm)));
            if (closeEnough(q, label)) {
                int d = lev(q, label);
                if (d < nearDist) {
                    nearDist = d;
                    near = ri;
                }
            }
        }
        return near;
    }

    private static String readAll(InputStream is) throws java.io.IOException {
        if (is == null) {
            return "";
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) {
            sb.append(line).append('\n');
        }
        r.close();
        return sb.toString();
    }

    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception ignored) {
            // no app can handle it
        }
    }

    /** Free Google Gemini: tries several models, moving on when one is busy (503/429) or missing (404). */
    private void askGemini(String id, String key, String system, String user) {
        // fastest first; the "-latest" names are thinking models and can take 10+ seconds
        String[] models = {"gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-flash-lite-latest", "gemini-flash-latest"};
        String lastError = "Gemini unavailable";
        try {
            JSONObject body = new JSONObject();
            body.put("systemInstruction", new JSONObject().put("parts",
                    new JSONArray().put(new JSONObject().put("text", system))));
            body.put("contents", new JSONArray().put(new JSONObject()
                    .put("role", "user")
                    .put("parts", new JSONArray().put(new JSONObject().put("text", user)))));
            for (int attempt = 0; attempt < models.length + 1; attempt++) {
                String m = models[attempt % models.length];
                try {
                    JSONObject gc = new JSONObject().put("maxOutputTokens", 600).put("temperature", 0.2);
                    if (m.startsWith("gemini-2.5")) {
                        gc.put("thinkingConfig", new JSONObject().put("thinkingBudget", 0)); // no "thinking" delay
                    }
                    body.put("generationConfig", gc);
                    byte[] payload = body.toString().getBytes("UTF-8");
                    HttpURLConnection c = (HttpURLConnection) new URL(
                            "https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent").openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(6000);
                    c.setReadTimeout(15000);
                    c.setDoOutput(true);
                    c.setRequestProperty("content-type", "application/json");
                    c.setRequestProperty("x-goog-api-key", key);
                    OutputStream os = c.getOutputStream();
                    os.write(payload);
                    os.close();

                    int code = c.getResponseCode();
                    boolean ok = code >= 200 && code < 300;
                    String resp = readAll(ok ? c.getInputStream() : c.getErrorStream());
                    if (ok) {
                        String text = new JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
                        js("window.__onAsk(" + JSONObject.quote(id) + ",true," + JSONObject.quote(text) + ")");
                        return;
                    }
                    String detail = "";
                    try {
                        detail = new JSONObject(resp).getJSONObject("error").getString("message");
                    } catch (Exception ignored) {
                        // body was not JSON
                    }
                    lastError = "Gemini error " + code + " (" + m + "): " + detail;
                    if (code == 400 || code == 401 || code == 403) {
                        break; // key or request problem: other models will not help
                    }
                    Thread.sleep(250);
                } catch (java.io.IOException e) {
                    lastError = String.valueOf(e.getMessage());
                }
            }
        } catch (Exception e) {
            lastError = String.valueOf(e.getMessage());
        }
        js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote(lastError) + ")");
    }

    // ------------------------------------------------------------------ JavaScript bridge

    public class Bridge {

        @JavascriptInterface
        public String info() {
            return "{\"native\":true,\"sdk\":" + Build.VERSION.SDK_INT + "}";
        }

        // ---- listening (Google speech recognition) ----

        @JavascriptInterface
        public void listen(final String lang) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!visible) {
                        js("window.__onSpeechError && window.__onSpeechError(100)");
                        return;
                    }
                    if (!has(Manifest.permission.RECORD_AUDIO)) {
                        js("window.__onSpeechError && window.__onSpeechError(9)");
                        requestRuntimePermissions();
                        return;
                    }
                    if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) {
                        js("window.__onSpeechError && window.__onSpeechError(5)");
                        return;
                    }
                    if (recognizer == null) {
                        recognizer = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
                        recognizer.setRecognitionListener(new RecognitionListener() {
                            @Override
                            public void onReadyForSpeech(Bundle params) {
                            }

                            @Override
                            public void onBeginningOfSpeech() {
                            }

                            @Override
                            public void onRmsChanged(float rmsdB) {
                            }

                            @Override
                            public void onBufferReceived(byte[] buffer) {
                            }

                            @Override
                            public void onEndOfSpeech() {
                            }

                            @Override
                            public void onError(int error) {
                                js("window.__onSpeechError && window.__onSpeechError(" + error + ")");
                            }

                            @Override
                            public void onResults(Bundle results) {
                                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                                if (list != null && !list.isEmpty()) {
                                    JSONArray alts = new JSONArray();
                                    for (int k = 1; k < list.size() && k < 5; k++) {
                                        alts.put(list.get(k));
                                    }
                                    js("window.__onSpeech && window.__onSpeech(" + JSONObject.quote(list.get(0)) + "," + alts.toString() + ")");
                                } else {
                                    js("window.__onSpeechError && window.__onSpeechError(7)");
                                }
                            }

                            @Override
                            public void onPartialResults(Bundle partialResults) {
                            }

                            @Override
                            public void onEvent(int eventType, Bundle params) {
                            }
                        });
                    }
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                    i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                    // finish as soon as the person stops talking (default waits ~2 s)
                    i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 550L);
                    i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 400L);
                    i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 300L);
                    i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                    i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
                    recognizer.cancel();
                    recognizer.startListening(i);
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (recognizer != null) {
                        recognizer.cancel();
                    }
                }
            });
        }

        // ---- speaking (Android text-to-speech) ----

        @JavascriptInterface
        public boolean hasSinhalaVoice() {
            try {
                return ttsReady && tts != null
                        && tts.isLanguageAvailable(new Locale("si", "LK")) >= TextToSpeech.LANG_AVAILABLE;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void speak(final String text, final String langTag) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!ttsReady || tts == null) {
                        js("window.__onSpeakDone && window.__onSpeakDone()");
                        return;
                    }
                    try {
                        Locale loc = Locale.forLanguageTag(langTag);
                        tts.setLanguage(loc);
                        Voice v = bestVoice(loc);
                        if (v != null) {
                            tts.setVoice(v);
                        }
                        tts.setPitch(1.1f);        // a little higher: softer, girl-like
                        tts.setSpeechRate(0.96f);  // slightly slower than default: less robotic
                    } catch (Exception ignored) {
                        // keep the previous voice
                    }
                    // clean up (emoji / symbols are read out loud by TTS) and speak sentence by sentence with small pauses
                    String clean = text == null ? "" : text
                            .replaceAll("[\\p{So}\\p{Cs}*_#`~<>|\\[\\]{}]", " ")
                            .replaceAll("\\s+", " ").trim();
                    if (clean.isEmpty()) {
                        js("window.__onSpeakDone && window.__onSpeakDone()");
                        return;
                    }
                    String[] parts = clean.split("(?<=[.!?\u0DF4\u2026])\\s+");
                    boolean first = true;
                    for (int i = 0; i < parts.length; i++) {
                        String part = parts[i].trim();
                        if (part.isEmpty()) {
                            continue;
                        }
                        boolean last = (i == parts.length - 1);
                        Bundle params = new Bundle();
                        int r = tts.speak(part, first ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, params, last ? "maya" : "maya_part");
                        if (r != TextToSpeech.SUCCESS) {
                            js("window.__onSpeakDone && window.__onSpeakDone()");
                            return;
                        }
                        first = false;
                        if (!last) {
                            tts.playSilentUtterance(160, TextToSpeech.QUEUE_ADD, "maya_gap");
                        }
                    }
                }
            });
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (tts != null) {
                        tts.stop();
                    }
                }
            });
        }

        // ---- Claude (called natively so no browser CORS limits apply) ----

        @JavascriptInterface
        public void ask(final String id, final String key, final String model, final String system, final String user) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (key != null && !key.startsWith("sk-ant")) {
                            askGemini(id, key, system, user);
                            return;
                        }
                        JSONObject body = new JSONObject();
                        body.put("model", model);
                        body.put("max_tokens", 500);
                        body.put("system", system);
                        JSONArray msgs = new JSONArray();
                        JSONObject m = new JSONObject();
                        m.put("role", "user");
                        m.put("content", user);
                        msgs.put(m);
                        body.put("messages", msgs);

                        HttpURLConnection c = (HttpURLConnection) new URL("https://api.anthropic.com/v1/messages").openConnection();
                        c.setRequestMethod("POST");
                        c.setConnectTimeout(8000);
                        c.setReadTimeout(25000);
                        c.setDoOutput(true);
                        c.setRequestProperty("content-type", "application/json");
                        c.setRequestProperty("x-api-key", key);
                        c.setRequestProperty("anthropic-version", "2023-06-01");
                        OutputStream os = c.getOutputStream();
                        os.write(body.toString().getBytes("UTF-8"));
                        os.close();

                        int code = c.getResponseCode();
                        boolean ok = code >= 200 && code < 300;
                        String resp = readAll(ok ? c.getInputStream() : c.getErrorStream());
                        if (ok) {
                            String text = new JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text");
                            js("window.__onAsk(" + JSONObject.quote(id) + ",true," + JSONObject.quote(text) + ")");
                        } else {
                            String detail = "";
                            try {
                                detail = new JSONObject(resp).getJSONObject("error").getString("message");
                            } catch (Exception ignored) {
                                // body was not JSON
                            }
                            js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote("API error " + code + ": " + detail) + ")");
                        }
                    } catch (Exception e) {
                        js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                    }
                }
            }).start();
        }

        // ---- "Maya" wake word (always listening, even when the app is closed) ----

        /** Returns "ok", "overlay" (permission screen opened) or "error". */
        @JavascriptInterface
        public String startWake(String unused) {
            try {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    launch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                    return "overlay";
                }
                getSharedPreferences(WakeService.PREFS, MODE_PRIVATE).edit().putBoolean(WakeService.PREF_ON, true).apply();
                Intent svc = new Intent(MainActivity.this, WakeService.class);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(svc);
                } else {
                    startService(svc);
                }
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public boolean isSiri() {
            return siriMode();
        }

        /** Closes the bottom orb (SiriActivity only). */
        @JavascriptInterface
        public void closeSiri() {
            if (siriMode()) {
                closing = true;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                });
            }
        }

        /** JS tells us whether an API key exists, so "open Maya" only goes straight to the orb once set up. */
        @JavascriptInterface
        public void setReady(boolean ready) {
            getSharedPreferences(WakeService.PREFS, MODE_PRIVATE).edit().putBoolean("ready", ready).apply();
        }

        @JavascriptInterface
        public void setSiriLaunch(boolean on) {
            getSharedPreferences(WakeService.PREFS, MODE_PRIVATE).edit().putBoolean("siri_launch", on).apply();
        }

        @JavascriptInterface
        public boolean siriLaunch() {
            return getSharedPreferences(WakeService.PREFS, MODE_PRIVATE).getBoolean("siri_launch", true);
        }

        /** "Maya settings": from the orb, open the full app (settings, history, notes). */
        @JavascriptInterface
        public void openFullApp() {
            closing = true;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(MainActivity.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    if (siriMode()) {
                        finish();
                    }
                }
            });
        }

        @JavascriptInterface
        public String wakeStatus() {
            return WakeService.status;
        }

        @JavascriptInterface
        public void stopWake() {
            getSharedPreferences(WakeService.PREFS, MODE_PRIVATE).edit().putBoolean(WakeService.PREF_ON, false).apply();
            stopService(new Intent(MainActivity.this, WakeService.class));
        }

        @JavascriptInterface
        public boolean wakeOn() {
            return WakeService.isRunning();
        }

        /** True once if the app was just opened by the wake word. */
        @JavascriptInterface
        public boolean consumeWake() {
            boolean w = wakePending;
            wakePending = false;
            return w;
        }

        @JavascriptInterface
        public void openBatterySettings() {
            launch(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }

        // ---- apps ----

        /** Opens an installed app by name. Returns the app's label, or "" when not found. */
        @JavascriptInterface
        public String openApp(String name) {
            ResolveInfo ri = findApp(name);
            if (ri == null) {
                return "";
            }
            Intent i = getPackageManager().getLaunchIntentForPackage(ri.activityInfo.packageName);
            if (i == null) {
                return "";
            }
            launch(i);
            return String.valueOf(ri.loadLabel(getPackageManager()));
        }

        /**
         * Closes an app. With a name: stops its background processes. Without a name: closes the
         * app currently on screen (needs the Accessibility service). Returns "ok", "notfound" or "a11y_off".
         */
        @JavascriptInterface
        public String closeApp(String name) {
            if (name == null || name.trim().isEmpty()) {
                return MayaAccessibilityService.perform("close_current", "");
            }
            ResolveInfo ri = findApp(name);
            if (ri == null) {
                return "notfound";
            }
            try {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                am.killBackgroundProcesses(ri.activityInfo.packageName);
            } catch (Exception ignored) {
                // best effort
            }
            return "ok";
        }

        @JavascriptInterface
        public String closeAllApps() {
            return MayaAccessibilityService.perform("close_all", "");
        }

        /** back, home, recents, notifications, quick_settings, lock, screenshot, scroll_down, scroll_up, tap */
        @JavascriptInterface
        public String phone(String action, String arg) {
            return MayaAccessibilityService.perform(action, arg);
        }

        @JavascriptInterface
        public boolean a11yEnabled() {
            return MayaAccessibilityService.instance != null;
        }

        @JavascriptInterface
        public void openA11ySettings() {
            launch(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }

        // ---- calls, messages, alarms, contacts, location ----

        /**
         * names may hold alternatives separated by "|" (e.g. "Amma|අම්මා|Mother"). Best match wins: exact, then
         * starts-with, then contains. If the whole name finds nothing, each single word of it is tried
         * (so "Kamal Perera" still finds a contact saved as "Kamal").
         */
        @JavascriptInterface
        public String contact(String names) {
            if (names == null || !has(Manifest.permission.READ_CONTACTS)) {
                return "";
            }
            String[] alts = names.split("\\|");
            for (String n : alts) {
                String r = findContactNumber(n.trim());
                if (!r.isEmpty()) {
                    return r;
                }
            }
            for (String n : alts) {
                for (String w : n.trim().split("\\s+")) {
                    if (w.length() >= 3) {
                        String r = findContactNumber(w);
                        if (!r.isEmpty()) {
                            return r;
                        }
                    }
                }
            }
            // last chance: similar spelling (speech recognition often mishears names)
            for (String n : alts) {
                String r = fuzzyContactNumber(norm(n));
                if (!r.isEmpty()) {
                    return r;
                }
            }
            return "";
        }

        private String fuzzyContactNumber(String qn) {
            if (qn.isEmpty()) {
                return "";
            }
            Cursor c = null;
            try {
                c = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER,
                                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME},
                        null, null, null);
                String best = "";
                int bestDist = 99;
                while (c != null && c.moveToNext()) {
                    String dn = norm(c.getString(1));
                    int d = Math.min(lev(qn, dn), 99);
                    String first = dn.contains(" ") ? dn.substring(0, dn.indexOf(' ')) : dn;
                    d = Math.min(d, lev(qn, first));
                    if (d < bestDist && (closeEnough(qn, dn) || closeEnough(qn, first))) {
                        bestDist = d;
                        best = c.getString(0);
                    }
                }
                return best.isEmpty() ? "" : best.replaceAll("[\\s-]", "");
            } catch (Exception ignored) {
                return "";
            } finally {
                if (c != null) {
                    c.close();
                }
            }
        }

        /** Names of the phone's contacts as a JSON array (lets the AI correct mis-heard names). */
        @JavascriptInterface
        public String contactNames() {
            JSONArray out = new JSONArray();
            if (!has(Manifest.permission.READ_CONTACTS)) {
                return out.toString();
            }
            Cursor c = null;
            try {
                c = getContentResolver().query(
                        ContactsContract.Contacts.CONTENT_URI,
                        new String[]{ContactsContract.Contacts.DISPLAY_NAME},
                        ContactsContract.Contacts.HAS_PHONE_NUMBER + " = 1", null,
                        ContactsContract.Contacts.TIMES_CONTACTED + " DESC");
                java.util.HashSet<String> seen = new java.util.HashSet<>();
                while (c != null && c.moveToNext() && out.length() < 300) {
                    String n = c.getString(0);
                    if (n != null && seen.add(n)) {
                        out.put(n);
                    }
                }
            } catch (Exception ignored) {
                // return what we have
            } finally {
                if (c != null) {
                    c.close();
                }
            }
            return out.toString();
        }

        private String findContactNumber(String q) {
            String qn = norm(q);
            if (qn.isEmpty()) {
                return "";
            }
            Cursor c = null;
            try {
                c = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER,
                                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME},
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                        new String[]{"%" + q + "%"},
                        null);
                String best = "";
                int bestRank = 99;
                while (c != null && c.moveToNext()) {
                    String dn = norm(c.getString(1));
                    int rank = dn.equals(qn) ? 0 : dn.startsWith(qn) ? 1 : 2;
                    if (rank < bestRank) {
                        bestRank = rank;
                        best = c.getString(0);
                    }
                }
                return best.isEmpty() ? "" : best.replaceAll("[\\s-]", "");
            } catch (Exception ignored) {
                return "";
            } finally {
                if (c != null) {
                    c.close();
                }
            }
        }

        /** Number for wa.me: digits only, with the country code (Sri Lanka 94 when the number starts with 0). */
        private String waNumber(String raw) {
            if (raw == null) {
                return "";
            }
            String d = raw.replaceAll("[^\\d+]", "");
            boolean plus = d.startsWith("+");
            d = d.replace("+", "");
            if (d.isEmpty()) {
                return "";
            }
            if (!plus && d.startsWith("00")) {
                return d.substring(2);
            }
            if (!plus && d.startsWith("0")) {
                return "94" + d.substring(1);
            }
            return d;
        }

        /** Opens the WhatsApp chat with the text filled in and presses Send. Returns "ok", "nowa", "notfound" or "a11y_off". */
        @JavascriptInterface
        public String whatsapp(String number, String text) {
            String n = waNumber(number);
            if (n.isEmpty()) {
                return "notfound";
            }
            Uri uri = Uri.parse("https://wa.me/" + n + "?text=" + Uri.encode(text == null ? "" : text));
            boolean started = false;
            for (String pkg : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
                Intent i = new Intent(Intent.ACTION_VIEW, uri);
                i.setPackage(pkg);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    startActivity(i);
                    started = true;
                    break;
                } catch (Exception ignored) {
                    // not installed: try the next one
                }
            }
            if (!started) {
                launch(new Intent(Intent.ACTION_VIEW, uri));
                return "nowa";
            }
            if (text == null || text.trim().isEmpty()) {
                return "ok"; // just open the chat
            }
            return MayaAccessibilityService.perform("wa_send", "");
        }

        /**
         * Opens ANY app, types the query in its search bar, presses search and (play=true) opens the first result.
         * Returns "ok", "notfound" (no such app) or "a11y_off".
         */
        @JavascriptInterface
        public String appSearch(String app, String query, boolean play) {
            String q = query == null ? "" : query.trim();
            if (openApp(app == null ? "" : app).isEmpty()) {
                return "notfound";
            }
            if (q.isEmpty()) {
                return "ok";
            }
            return MayaAccessibilityService.perform(play ? "app_search_play" : "app_search", q);
        }

        /** Android's "Default digital assistant" screen: pick Maya AI there to get the Siri-style orb from the power button / corner swipe. */
        @JavascriptInterface
        public void openAssistSettings() {
            try {
                launch(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS));
            } catch (Exception e) {
                launch(new Intent(Settings.ACTION_SETTINGS));
            }
        }

        /** Searches YouTube and starts the first video. Returns "ok", "notfound" or "a11y_off" (results still open). */
        @JavascriptInterface
        public String youtube(String query) {
            String q = query == null ? "" : query.trim();
            if (q.isEmpty()) {
                return openApp("youtube").isEmpty() ? "notfound" : "ok";
            }
            Intent i = new Intent(Intent.ACTION_SEARCH);
            i.setPackage("com.google.android.youtube");
            i.putExtra("query", q);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(i);
            } catch (Exception e) {
                Intent v = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)));
                v.setPackage("com.google.android.youtube");
                v.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    startActivity(v);
                } catch (Exception e2) {
                    launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))));
                    return "ok"; // browser fallback: no auto-play
                }
            }
            return MayaAccessibilityService.perform("yt_play", "");
        }

        @JavascriptInterface
        public void call(String number) {
            Uri uri = Uri.parse("tel:" + Uri.encode(number));
            launch(new Intent(has(Manifest.permission.CALL_PHONE) ? Intent.ACTION_CALL : Intent.ACTION_DIAL, uri));
        }

        @JavascriptInterface
        public void sms(String number, String text) {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)));
            i.putExtra("sms_body", text);
            launch(i);
        }

        @JavascriptInterface
        public void alarm(int hour, int minute, String label) {
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
            i.putExtra(AlarmClock.EXTRA_HOUR, hour);
            i.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, label == null ? "Maya" : label);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            launch(i);
        }

        @JavascriptInterface
        public void timer(int seconds) {
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
            i.putExtra(AlarmClock.EXTRA_LENGTH, seconds);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            launch(i);
        }

        @JavascriptInterface
        public void openUrl(String url) {
            launch(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        }

        /** "lat,lon" of the last known location, or "". */
        @JavascriptInterface
        public String location() {
            try {
                if (!has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    return "";
                }
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                Location best = null;
                for (String p : lm.getProviders(true)) {
                    Location l = lm.getLastKnownLocation(p);
                    if (l != null && (best == null || l.getAccuracy() < best.getAccuracy())) {
                        best = l;
                    }
                }
                if (best != null) {
                    return best.getLatitude() + "," + best.getLongitude();
                }
            } catch (Exception ignored) {
                // no location
            }
            return "";
        }
    }
}
