package com.maya.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Always-on "Maya" wake word listener (Vosk, offline, free). When "Maya" is heard it opens the
 * app and starts listening. While the app is on screen the listener pauses (one microphone user at a time).
 * The small English model (~40 MB) is downloaded once on first start.
 */
public class WakeService extends Service {

    public static final String PREFS = "maya";
    public static final String PREF_ON = "wake_on";
    private static final String CHANNEL = "maya_wake";
    private static final String MODEL_NAME = "vosk-model-small-en-us-0.15";
    private static final String MODEL_URL = "https://alphacephei.com/vosk/models/" + MODEL_NAME + ".zip";

    static volatile WakeService instance;
    static volatile String status = "";
    private static volatile boolean appVisible = false;

    private Model model;
    private SpeechService speech;
    private boolean listening = false;
    private volatile boolean loading = false;
    private long lastWake = 0;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable resumeTask = new Runnable() {
        @Override
        public void run() {
            if (!appVisible) {
                startListening();
            }
        }
    };

    /** Called by MainActivity: true while the app is on screen. */
    public static void setAppVisible(boolean visible) {
        appVisible = visible;
        WakeService s = instance;
        if (s == null) {
            return;
        }
        s.main.removeCallbacks(s.resumeTask);
        if (visible) {
            s.stopListening();
        } else {
            s.main.postDelayed(s.resumeTask, 1200);
        }
    }

    public static boolean isRunning() {
        return instance != null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Maya wake word", NotificationManager.IMPORTANCE_LOW));
        }
        Notification n = notification("Maya wake word", "Starting...");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(7, n);
        }
    }

    private Notification notification(String title, String text) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void note(String text) {
        status = text;
        try {
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(7, notification("Maya wake word", text));
        } catch (Exception ignored) {
            // no notification permission
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!appVisible) {
            startListening();
        }
        return START_STICKY;
    }

    private void startListening() {
        if (listening || loading) {
            return;
        }
        if (model != null) {
            beginRecognition();
            return;
        }
        loading = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    File dir = new File(getFilesDir(), MODEL_NAME);
                    if (!new File(dir, "am").exists()) {
                        note("Downloading voice model (~40 MB)...");
                        download(dir.getParentFile());
                    }
                    model = new Model(dir.getAbsolutePath());
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            loading = false;
                            if (!appVisible) {
                                beginRecognition();
                            }
                        }
                    });
                } catch (Exception e) {
                    loading = false;
                    note("Model error: " + e.getMessage());
                }
            }
        }).start();
    }

    private void download(File parent) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(MODEL_URL).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        InputStream in = c.getInputStream();
        ZipInputStream zin = new ZipInputStream(in);
        ZipEntry e;
        byte[] buf = new byte[65536];
        while ((e = zin.getNextEntry()) != null) {
            File out = new File(parent, e.getName());
            if (!out.getCanonicalPath().startsWith(parent.getCanonicalPath())) {
                continue; // zip-slip guard
            }
            if (e.isDirectory()) {
                out.mkdirs();
            } else {
                out.getParentFile().mkdirs();
                FileOutputStream fo = new FileOutputStream(out);
                int n;
                while ((n = zin.read(buf)) > 0) {
                    fo.write(buf, 0, n);
                }
                fo.close();
            }
        }
        zin.close();
    }

    private void beginRecognition() {
        if (listening || model == null) {
            return;
        }
        try {
            Recognizer rec = new Recognizer(model, 16000.0f, "[\"maya\", \"[unk]\"]");
            rec.setWords(true); // per-word confidence, used to ignore weak matches
            speech = new SpeechService(rec, 16000.0f);
            speech.startListening(new RecognitionListener() {
                @Override
                public void onPartialResult(String hypothesis) {
                    // partial guesses are noisy and caused random wake-ups: wait for the finished phrase
                }

                @Override
                public void onResult(String hypothesis) {
                    check(hypothesis);
                }

                @Override
                public void onFinalResult(String hypothesis) {
                }

                @Override
                public void onError(Exception exception) {
                    note("Mic error: " + exception.getMessage());
                }

                @Override
                public void onTimeout() {
                }
            });
            listening = true;
            note("Listening for \"Maya\"");
        } catch (Exception e) {
            listening = false;
            note("Start error: " + e.getMessage());
        }
    }

    /**
     * Wakes Maya only when the finished phrase is really "Maya": it must be the first or last word of a short
     * phrase and the recognizer must be confident about it. Everyday talk no longer opens the orb.
     */
    private void check(String json) {
        if (json == null) {
            return;
        }
        try {
            org.json.JSONObject o = new org.json.JSONObject(json);
            String text = o.optString("text", "").trim().toLowerCase(java.util.Locale.ROOT);
            if (text.isEmpty()) {
                return;
            }
            String[] tok = text.split("\\s+");
            if (tok.length > 4) {
                return;
            }
            if (!tok[0].equals("maya") && !tok[tok.length - 1].equals("maya")) {
                return;
            }
            org.json.JSONArray words = o.optJSONArray("result");
            if (words != null) {
                double best = 0;
                boolean found = false;
                for (int i = 0; i < words.length(); i++) {
                    org.json.JSONObject w = words.getJSONObject(i);
                    if ("maya".equals(w.optString("word"))) {
                        found = true;
                        best = Math.max(best, w.optDouble("conf", 1.0));
                    }
                }
                if (found && best < 0.85) {
                    return; // not sure enough
                }
            }
        } catch (Exception e) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastWake > 4000) {
            lastWake = now;
            main.post(new Runnable() {
                @Override
                public void run() {
                    onWake();
                }
            });
        }
    }

    private void stopListening() {
        if (speech != null) {
            try {
                speech.stop();
                speech.shutdown();
            } catch (Exception ignored) {
                // already stopped
            }
            speech = null;
        }
        listening = false;
    }

    private void onWake() {
        stopListening();
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            PowerManager.WakeLock wl = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "maya:wake");
            wl.acquire(10000);
        } catch (Exception ignored) {
            // best effort
        }
        Intent i = new Intent(this, SiriActivity.class);
        i.putExtra("wake", true);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try {
            startActivity(i);
        } catch (Exception e) {
            beginRecognition(); // could not open the app (overlay permission?): keep listening
        }
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(resumeTask);
        stopListening();
        if (model != null) {
            model.close();
            model = null;
        }
        instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
