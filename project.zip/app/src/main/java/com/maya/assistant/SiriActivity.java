package com.maya.assistant;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;

/**
 * Siri-style "Maya" screen: a transparent window at the bottom of the screen that shows only the orb
 * on top of whatever app is open. Touches outside the orb go to the app underneath.
 */
public class SiriActivity extends MainActivity {

    @Override
    protected boolean siriMode() {
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        // The orb only shows: touches and focus stay with the app underneath (so swipes/taps reach it).
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        float d = getResources().getDisplayMetrics().density;
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (int) (240 * d));
        getWindow().setGravity(Gravity.BOTTOM);
    }

    /**
     * When Maya opens another app (YouTube, WhatsApp, ...) that app comes to the front and this orb window would
     * disappear. So if the stop was caused by an app Maya just opened, bring the orb back on top of that app a
     * moment later and keep listening: "open YouTube" ... "scroll up" ... "next video" all in one go.
     * (Needs "Display over other apps" for Maya AI, same as the wake word.)
     */
    @Override
    protected void onStop() {
        super.onStop();
        boolean comeBack = !closing && SystemClock.uptimeMillis() - lastAppLaunch < 3500;
        finish();
        if (comeBack) {
            final Context app = getApplicationContext();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(app, SiriActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        i.putExtra("wake", true);
                        app.startActivity(i);
                    } catch (Exception ignored) {
                        // not allowed (overlay permission missing): the orb simply stays closed
                    }
                }
            }, 1000);
        }
    }
}
