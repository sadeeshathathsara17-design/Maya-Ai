package com.maya.assistant;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;

/**
 * Siri-style "Maya" screen: a transparent window at the bottom of the screen that shows only the orb
 * on top of whatever app is open. Touches outside the orb go to the app underneath.
 */
public class SiriActivity extends MainActivity {

    @Override
    protected boolean siriMode() {
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        // The orb only shows: touches and focus stay with the app underneath (so swipes/taps reach it).
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        float d = getResources().getDisplayMetrics().density;
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (int) (240 * d));
        getWindow().setGravity(Gravity.BOTTOM);
    }

    /** The orb is transient: when another app comes to the front (e.g. "open YouTube"), it goes away. */
    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }
}
