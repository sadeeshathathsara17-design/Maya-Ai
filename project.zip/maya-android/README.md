# Maya AI (Android)
Voice assistant app: Sinhala/English speech, open & close apps, calls, SMS, alarms, weather.
The screen (app/src/main/assets/index.html) runs inside a WebView and talks to the phone through the `Android` JavaScript bridge (MainActivity.java).
Phone-wide control (Back/Home, close apps, tap, scroll) needs the Accessibility service switched on once.
Build: push to GitHub; the workflow in .github/workflows/build.yml produces Maya-AI.apk under Releases.
