package com.maya.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/**
 * Lets Maya press Back/Home/Recents, scroll, tap on-screen text and close apps
 * (by opening the recent-apps screen and swiping the card away).
 * The user must switch this service on once in Android Settings > Accessibility.
 */
public class MayaAccessibilityService extends AccessibilityService {

    static volatile MayaAccessibilityService instance;

    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // not used
    }

    @Override
    public void onInterrupt() {
        // not used
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    /** Called from the JavaScript bridge (any thread). Returns "ok", "a11y_off", "notfound" or "unknown". */
    static String perform(final String action, final String arg) {
        final MayaAccessibilityService s = instance;
        if (s == null) {
            return "a11y_off";
        }
        if (action == null) {
            return "unknown";
        }
        switch (action) {
            case "back":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_BACK));
                return "ok";
            case "home":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_HOME));
                return "ok";
            case "recents":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_RECENTS));
                return "ok";
            case "notifications":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS));
                return "ok";
            case "quick_settings":
                s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS));
                return "ok";
            case "lock":
                if (Build.VERSION.SDK_INT >= 28) {
                    s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN));
                }
                return "ok";
            case "screenshot":
                if (Build.VERSION.SDK_INT >= 28) {
                    s.main.post(() -> s.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT));
                }
                return "ok";
            case "scroll_down":
                s.main.post(() -> s.swipe(0.5f, 0.72f, 0.5f, 0.28f, 320));
                return "ok";
            case "scroll_up":
                s.main.post(() -> s.swipe(0.5f, 0.28f, 0.5f, 0.72f, 320));
                return "ok";
            case "tap":
                final boolean[] result = new boolean[1];
                final Object lock = new Object();
                s.main.post(() -> {
                    result[0] = s.tapText(arg);
                    synchronized (lock) {
                        lock.notifyAll();
                    }
                });
                synchronized (lock) {
                    try {
                        lock.wait(1500);
                    } catch (InterruptedException ignored) {
                        // fall through
                    }
                }
                return result[0] ? "ok" : "notfound";
            case "close_current":
                s.main.post(s::closeCurrentApp);
                return "ok";
            case "close_all":
                s.main.post(s::closeAllApps);
                return "ok";
            default:
                return "unknown";
        }
    }

    private void swipe(float x1, float y1, float x2, float y2, long durationMs) {
        DisplayMetrics m = getResources().getDisplayMetrics();
        Path p = new Path();
        p.moveTo(m.widthPixels * x1, m.heightPixels * y1);
        p.lineTo(m.widthPixels * x2, m.heightPixels * y2);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, durationMs));
        dispatchGesture(b.build(), null, null);
    }

    /** Finds a visible node whose text/description contains the given text and clicks it (or its clickable parent). */
    private boolean tapText(String text) {
        if (text == null || text.trim().isEmpty()) {
            return false;
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            return false;
        }
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(text);
        if (nodes == null) {
            return false;
        }
        for (AccessibilityNodeInfo n : nodes) {
            AccessibilityNodeInfo cur = n;
            int hops = 0;
            while (cur != null && hops < 8) {
                if (cur.isClickable() && cur.isEnabled()) {
                    if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true;
                    }
                }
                cur = cur.getParent();
                hops++;
            }
        }
        return false;
    }

    /** Opens the recent-apps screen, swipes the front card up (dismisses it), then goes Home. */
    private void closeCurrentApp() {
        performGlobalAction(GLOBAL_ACTION_RECENTS);
        main.postDelayed(() -> swipe(0.5f, 0.55f, 0.5f, 0.06f, 260), 900);
        main.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_HOME), 1700);
    }

    /** Opens recents and taps "Close all" / "Clear all", then goes Home. */
    private void closeAllApps() {
        performGlobalAction(GLOBAL_ACTION_RECENTS);
        main.postDelayed(() -> {
            String[] labels = {"Close all", "Clear all", "Close All", "Clear All", "CLOSE ALL", "CLEAR ALL"};
            for (String l : labels) {
                if (tapText(l)) {
                    break;
                }
            }
        }, 1000);
        main.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_HOME), 1900);
    }
}
