package com.maya.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;


public class WakeService extends Service {
    private static final String CHANNEL = "maya_wake";
    private static final String MODEL_NAME = "vosk-model-small-en-us-0.15";
    private static final String MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip";
    public static final String PREFS = "maya";
    public static final String PREF_ON = "wake_on";
    static volatile WakeService instance;
    private Model model;
    private SpeechService speech;
    static volatile String status = "";
    private static volatile boolean appVisible = false;
    private boolean listening = false;
    private volatile boolean loading = false;
    private long lastWake = 0;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable resumeTask = new Runnable() { // from class: com.maya.assistant.WakeService.1
        @Override // java.lang.Runnable
        public void run() {
            if (!WakeService.appVisible) {
                WakeService.this.startListening();
            }
        }
    };

    public static void setAppVisible(boolean visible) {
        appVisible = visible;
        WakeService s = instance;
        if (s == null) {
            return;
        }
        s.main.removeCallbacks(s.resumeTask);
        if (visible) {
            s.stopListening();
        } else {
            s.main.postDelayed(s.resumeTask, 1200L);
        }
    }

    public static boolean isRunning() {
        return instance != null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        instance = this;
        NotificationManager nm = (NotificationManager) getSystemService("notification");
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Maya wake word", 2));
        Notification n = notification("Maya wake word", "Starting...");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, 128);
        } else {
            startForeground(7, n);
        }
    }

    private Notification notification(String title, String text) {
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) MainActivity.class), 67108864);
        return new Notification.Builder(this, CHANNEL).setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
    }

    public void note(String text) {
        status = text;
        try {
            ((NotificationManager) getSystemService("notification")).notify(7, notification("Maya wake word", text));
        } catch (Exception e) {
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!appVisible) {
            startListening();
            return 1;
        }
        return 1;
    }

    public void startListening() {
        if (this.listening || this.loading) {
            return;
        }
        if (this.model != null) {
            beginRecognition();
        } else {
            this.loading = true;
            new Thread(new Runnable() { // from class: com.maya.assistant.WakeService.2
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        File dir = new File(WakeService.this.getFilesDir(), WakeService.MODEL_NAME);
                        if (!new File(dir, "am").exists()) {
                            WakeService.this.note("Downloading voice model (~40 MB)...");
                            WakeService.this.download(dir.getParentFile());
                        }
                        WakeService.this.model = new Model(dir.getAbsolutePath());
                        WakeService.this.main.post(new Runnable() { // from class: com.maya.assistant.WakeService.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                WakeService.this.loading = false;
                                if (!WakeService.appVisible) {
                                    WakeService.this.beginRecognition();
                                }
                            }
                        });
                    } catch (Exception e) {
                        WakeService.this.loading = false;
                        WakeService.this.note("Model error: " + e.getMessage());
                    }
                }
            }).start();
        }
    }

    public void download(File parent) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(MODEL_URL).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        InputStream in = c.getInputStream();
        ZipInputStream zin = new ZipInputStream(in);
        byte[] buf = new byte[65536];
        while (true) {
            ZipEntry e = zin.getNextEntry();
            if (e != null) {
                File out = new File(parent, e.getName());
                if (out.getCanonicalPath().startsWith(parent.getCanonicalPath())) {
                    if (e.isDirectory()) {
                        out.mkdirs();
                    } else {
                        out.getParentFile().mkdirs();
                        FileOutputStream fo = new FileOutputStream(out);
                        while (true) {
                            int n = zin.read(buf);
                            if (n <= 0) {
                                break;
                            } else {
                                fo.write(buf, 0, n);
                            }
                        }
                        fo.close();
                    }
                }
            } else {
                zin.close();
                return;
            }
        }
    }

    public void beginRecognition() {
        if (this.listening || this.model == null) {
            return;
        }
        try {
            Recognizer rec = new Recognizer(this.model, 16000.0f, "[\"maya\", \"[unk]\"]");
            this.speech = new SpeechService(rec, 16000.0f);
            this.speech.startListening(new RecognitionListener() { // from class: com.maya.assistant.WakeService.3
                @Override // org.vosk.android.RecognitionListener
                public void onPartialResult(String hypothesis) {
                    WakeService.this.check(hypothesis);
                }

                @Override // org.vosk.android.RecognitionListener
                public void onResult(String hypothesis) {
                    WakeService.this.check(hypothesis);
                }

                @Override // org.vosk.android.RecognitionListener
                public void onFinalResult(String hypothesis) {
                }

                @Override // org.vosk.android.RecognitionListener
                public void onError(Exception exception) {
                    WakeService.this.note("Mic error: " + exception.getMessage());
                }

                @Override // org.vosk.android.RecognitionListener
                public void onTimeout() {
                }
            });
            this.listening = true;
            note("Listening for \"Maya\"");
        } catch (Exception e) {
            this.listening = false;
            note("Start error: " + e.getMessage());
        }
    }

    public void check(String json) {
        if (json != null && json.toLowerCase().contains(PREFS)) {
            long now = System.currentTimeMillis();
            if (now - this.lastWake > 3000) {
                this.lastWake = now;
                this.main.post(new Runnable() { // from class: com.maya.assistant.WakeService.4
                    @Override // java.lang.Runnable
                    public void run() {
                        WakeService.this.onWake();
                    }
                });
            }
        }
    }

    private void stopListening() {
        if (this.speech != null) {
            try {
                this.speech.stop();
                this.speech.shutdown();
            } catch (Exception e) {
            }
            this.speech = null;
        }
        this.listening = false;
    }

    public void onWake() {
        stopListening();
        try {
            PowerManager pm = (PowerManager) getSystemService("power");
            PowerManager.WakeLock wl = pm.newWakeLock(268435466, "maya:wake");
            wl.acquire(10000L);
        } catch (Exception e) {
        }
        Intent i = new Intent(this, (Class<?>) SiriActivity.class);
        i.putExtra("wake", true);
        i.addFlags(805437440);
        try {
            startActivity(i);
        } catch (Exception e2) {
            beginRecognition();
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.main.removeCallbacks(this.resumeTask);
        stopListening();
        if (this.model != null) {
            this.model.close();
            this.model = null;
        }
        instance = null;
        super.onDestroy();
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }
}
