package com.maya.assistant;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;


public class SiriActivity extends MainActivity {
    @Override // com.maya.assistant.MainActivity
    protected boolean siriMode() {
        return true;
    }

    @Override // com.maya.assistant.MainActivity, android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(0));
        getWindow().clearFlags(2);
        getWindow().addFlags(568);
        float d = getResources().getDisplayMetrics().density;
        getWindow().setLayout(-1, (int) (330.0f * d));
        getWindow().setGravity(80);
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        finish();
    }
}
