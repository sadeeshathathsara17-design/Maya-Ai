package com.maya.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Hosts the Maya AI screen (assets/index.html) in a WebView and gives it real phone powers
 * through the JavaScript object "Android": speech in/out, open/close apps, calls, SMS,
 * alarms, contacts and (with the Accessibility service) taps, scrolling and Back/Home.
 */
public class MainActivity extends Activity {

    private static final Map<String, String> ALIASES = new HashMap<>();

    static {
        ALIASES.put("fb", "facebook");
        ALIASES.put("face book", "facebook");
        ALIASES.put("yt", "youtube");
        ALIASES.put("you tube", "youtube");
        ALIASES.put("whats app", "whatsapp");
        ALIASES.put("insta", "instagram");
        ALIASES.put("tik tok", "tiktok");
        ALIASES.put("google chrome", "chrome");
        ALIASES.put("play store", "play store");
    }

    private WebView web;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile boolean visible = false;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xFF030814);
        getWindow().setNavigationBarColor(0xFF030814);

        web = new WebView(this);
        web.setBackgroundColor(0xFF030814);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");

        initTts();
        requestRuntimePermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        js("window.__onResume && window.__onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        visible = false;
        if (recognizer != null) {
            recognizer.cancel();
        }
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
                "(function(){var s=document.querySelector('.view.sub.on');if(s){s.classList.remove('on');return 'closed';}return 'none';})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (value == null || !value.contains("closed")) {
                            MainActivity.super.onBackPressed();
                        }
                    }
                });
    }

    // ------------------------------------------------------------------ helpers

    private void js(final String code) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript(code, null);
                }
            }
        });
    }

    private boolean has(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestRuntimePermissions() {
        List<String> need = new ArrayList<>();
        String[] wanted = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.ACCESS_COARSE_LOCATION
        };
        for (String p : wanted) {
            if (!has(p)) {
                need.add(p);
            }
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), 1);
        }
    }

    private void initTts() {
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                ttsReady = (status == TextToSpeech.SUCCESS);
                if (ttsReady && tts != null) {
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override
                        public void onStart(String utteranceId) {
                        }

                        @Override
                        public void onDone(String utteranceId) {
                            js("window.__onSpeakDone && window.__onSpeakDone()");
                        }

                        @Override
                        public void onError(String utteranceId) {
                            js("window.__onSpeakDone && window.__onSpeakDone()");
                        }
                    });
                }
            }
        });
    }

    private static String norm(String s) {
        if (s == null) {
            return "";
        }
        return s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N} ]", "").trim();
    }

    /** Finds an installed launchable app by (approximate) name. */
    private ResolveInfo findApp(String name) {
        String q = norm(name);
        if (q.isEmpty()) {
            return null;
        }
        String alias = ALIASES.get(q);
        if (alias != null) {
            q = alias;
        }
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
        ResolveInfo exact = null;
        ResolveInfo starts = null;
        ResolveInfo contains = null;
        String compact = q.replace(" ", "");
        for (ResolveInfo ri : list) {
            String label = norm(String.valueOf(ri.loadLabel(pm)));
            String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
            if (label.equals(q)) {
                exact = ri;
                break;
            }
            if (starts == null && label.startsWith(q)) {
                starts = ri;
            }
            if (contains == null && (label.contains(q) || pkg.contains(compact))) {
                contains = ri;
            }
        }
        if (exact != null) {
            return exact;
        }
        return starts != null ? starts : contains;
    }

    private static String readAll(InputStream is) throws java.io.IOException {
        if (is == null) {
            return "";
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) {
            sb.append(line).append('\n');
        }
        r.close();
        return sb.toString();
    }

    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception ignored) {
            // no app can handle it
        }
    }

    /** Free Google Gemini fallback: used when the key in Profile starts with "AIza". */
    private void askGemini(String id, String key, String system, String user) {
        try {
            JSONObject body = new JSONObject();
            body.put("systemInstruction", new JSONObject().put("parts",
                    new JSONArray().put(new JSONObject().put("text", system))));
            body.put("contents", new JSONArray().put(new JSONObject()
                    .put("role", "user")
                    .put("parts", new JSONArray().put(new JSONObject().put("text", user)))));
            body.put("generationConfig", new JSONObject().put("maxOutputTokens", 900));

            HttpURLConnection c = (HttpURLConnection) new URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent").openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            c.setDoOutput(true);
            c.setRequestProperty("content-type", "application/json");
            c.setRequestProperty("x-goog-api-key", key);
            OutputStream os = c.getOutputStream();
            os.write(body.toString().getBytes("UTF-8"));
            os.close();

            int code = c.getResponseCode();
            boolean ok = code >= 200 && code < 300;
            String resp = readAll(ok ? c.getInputStream() : c.getErrorStream());
            if (ok) {
                String text = new JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
                js("window.__onAsk(" + JSONObject.quote(id) + ",true," + JSONObject.quote(text) + ")");
            } else {
                String detail = "";
                try {
                    detail = new JSONObject(resp).getJSONObject("error").getString("message");
                } catch (Exception ignored) {
                    // body was not JSON
                }
                js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote("Gemini error " + code + ": " + detail) + ")");
            }
        } catch (Exception e) {
            js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
        }
    }

    // ------------------------------------------------------------------ JavaScript bridge

    public class Bridge {

        @JavascriptInterface
        public String info() {
            return "{\"native\":true,\"sdk\":" + Build.VERSION.SDK_INT + "}";
        }

        // ---- listening (Google speech recognition) ----

        @JavascriptInterface
        public void listen(final String lang) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!visible) {
                        js("window.__onSpeechError && window.__onSpeechError(100)");
                        return;
                    }
                    if (!has(Manifest.permission.RECORD_AUDIO)) {
                        js("window.__onSpeechError && window.__onSpeechError(9)");
                        requestRuntimePermissions();
                        return;
                    }
                    if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) {
                        js("window.__onSpeechError && window.__onSpeechError(5)");
                        return;
                    }
                    if (recognizer == null) {
                        recognizer = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
                        recognizer.setRecognitionListener(new RecognitionListener() {
                            @Override
                            public void onReadyForSpeech(Bundle params) {
                            }

                            @Override
                            public void onBeginningOfSpeech() {
                            }

                            @Override
                            public void onRmsChanged(float rmsdB) {
                            }

                            @Override
                            public void onBufferReceived(byte[] buffer) {
                            }

                            @Override
                            public void onEndOfSpeech() {
                            }

                            @Override
                            public void onError(int error) {
                                js("window.__onSpeechError && window.__onSpeechError(" + error + ")");
                            }

                            @Override
                            public void onResults(Bundle results) {
                                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                                if (list != null && !list.isEmpty()) {
                                    js("window.__onSpeech && window.__onSpeech(" + JSONObject.quote(list.get(0)) + ")");
                                } else {
                                    js("window.__onSpeechError && window.__onSpeechError(7)");
                                }
                            }

                            @Override
                            public void onPartialResults(Bundle partialResults) {
                            }

                            @Override
                            public void onEvent(int eventType, Bundle params) {
                            }
                        });
                    }
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                    i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
                    i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
                    recognizer.cancel();
                    recognizer.startListening(i);
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (recognizer != null) {
                        recognizer.cancel();
                    }
                }
            });
        }

        // ---- speaking (Android text-to-speech) ----

        @JavascriptInterface
        public boolean hasSinhalaVoice() {
            try {
                return ttsReady && tts != null
                        && tts.isLanguageAvailable(new Locale("si", "LK")) >= TextToSpeech.LANG_AVAILABLE;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void speak(final String text, final String langTag) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!ttsReady || tts == null) {
                        js("window.__onSpeakDone && window.__onSpeakDone()");
                        return;
                    }
                    try {
                        tts.setLanguage(Locale.forLanguageTag(langTag));
                    } catch (Exception ignored) {
                        // keep the previous language
                    }
                    int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), "maya");
                    if (r != TextToSpeech.SUCCESS) {
                        js("window.__onSpeakDone && window.__onSpeakDone()");
                    }
                }
            });
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (tts != null) {
                        tts.stop();
                    }
                }
            });
        }

        // ---- Claude (called natively so no browser CORS limits apply) ----

        @JavascriptInterface
        public void ask(final String id, final String key, final String model, final String system, final String user) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (key != null && key.startsWith("AIza")) {
                            askGemini(id, key, system, user);
                            return;
                        }
                        JSONObject body = new JSONObject();
                        body.put("model", model);
                        body.put("max_tokens", 900);
                        body.put("system", system);
                        JSONArray msgs = new JSONArray();
                        JSONObject m = new JSONObject();
                        m.put("role", "user");
                        m.put("content", user);
                        msgs.put(m);
                        body.put("messages", msgs);

                        HttpURLConnection c = (HttpURLConnection) new URL("https://api.anthropic.com/v1/messages").openConnection();
                        c.setRequestMethod("POST");
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(60000);
                        c.setDoOutput(true);
                        c.setRequestProperty("content-type", "application/json");
                        c.setRequestProperty("x-api-key", key);
                        c.setRequestProperty("anthropic-version", "2023-06-01");
                        OutputStream os = c.getOutputStream();
                        os.write(body.toString().getBytes("UTF-8"));
                        os.close();

                        int code = c.getResponseCode();
                        boolean ok = code >= 200 && code < 300;
                        String resp = readAll(ok ? c.getInputStream() : c.getErrorStream());
                        if (ok) {
                            String text = new JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text");
                            js("window.__onAsk(" + JSONObject.quote(id) + ",true," + JSONObject.quote(text) + ")");
                        } else {
                            String detail = "";
                            try {
                                detail = new JSONObject(resp).getJSONObject("error").getString("message");
                            } catch (Exception ignored) {
                                // body was not JSON
                            }
                            js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote("API error " + code + ": " + detail) + ")");
                        }
                    } catch (Exception e) {
                        js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                    }
                }
            }).start();
        }

        // ---- apps ----

        /** Opens an installed app by name. Returns the app's label, or "" when not found. */
        @JavascriptInterface
        public String openApp(String name) {
            ResolveInfo ri = findApp(name);
            if (ri == null) {
                return "";
            }
            Intent i = getPackageManager().getLaunchIntentForPackage(ri.activityInfo.packageName);
            if (i == null) {
                return "";
            }
            launch(i);
            return String.valueOf(ri.loadLabel(getPackageManager()));
        }

        /**
         * Closes an app. With a name: stops its background processes. Without a name: closes the
         * app currently on screen (needs the Accessibility service). Returns "ok", "notfound" or "a11y_off".
         */
        @JavascriptInterface
        public String closeApp(String name) {
            if (name == null || name.trim().isEmpty()) {
                return MayaAccessibilityService.perform("close_current", "");
            }
            ResolveInfo ri = findApp(name);
            if (ri == null) {
                return "notfound";
            }
            try {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                am.killBackgroundProcesses(ri.activityInfo.packageName);
            } catch (Exception ignored) {
                // best effort
            }
            return "ok";
        }

        @JavascriptInterface
        public String closeAllApps() {
            return MayaAccessibilityService.perform("close_all", "");
        }

        /** back, home, recents, notifications, quick_settings, lock, screenshot, scroll_down, scroll_up, tap */
        @JavascriptInterface
        public String phone(String action, String arg) {
            return MayaAccessibilityService.perform(action, arg);
        }

        @JavascriptInterface
        public boolean a11yEnabled() {
            return MayaAccessibilityService.instance != null;
        }

        @JavascriptInterface
        public void openA11ySettings() {
            launch(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        }

        // ---- calls, messages, alarms, contacts, location ----

        /** names may hold alternatives separated by "|" (e.g. "Amma|අම්මා|Mother"). */
        @JavascriptInterface
        public String contact(String names) {
            if (names == null || !has(Manifest.permission.READ_CONTACTS)) {
                return "";
            }
            for (String n : names.split("\\|")) {
                String q = n.trim();
                if (q.isEmpty()) {
                    continue;
                }
                Cursor c = null;
                try {
                    c = getContentResolver().query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                            new String[]{"%" + q + "%"},
                            null);
                    if (c != null && c.moveToFirst()) {
                        return c.getString(0);
                    }
                } catch (Exception ignored) {
                    // try the next spelling
                } finally {
                    if (c != null) {
                        c.close();
                    }
                }
            }
            return "";
        }

        @JavascriptInterface
        public void call(String number) {
            Uri uri = Uri.parse("tel:" + Uri.encode(number));
            launch(new Intent(has(Manifest.permission.CALL_PHONE) ? Intent.ACTION_CALL : Intent.ACTION_DIAL, uri));
        }

        @JavascriptInterface
        public void sms(String number, String text) {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)));
            i.putExtra("sms_body", text);
            launch(i);
        }

        @JavascriptInterface
        public void alarm(int hour, int minute, String label) {
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
            i.putExtra(AlarmClock.EXTRA_HOUR, hour);
            i.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, label == null ? "Maya" : label);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            launch(i);
        }

        @JavascriptInterface
        public void timer(int seconds) {
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
            i.putExtra(AlarmClock.EXTRA_LENGTH, seconds);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            launch(i);
        }

        @JavascriptInterface
        public void openUrl(String url) {
            launch(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        }

        /** "lat,lon" of the last known location, or "". */
        @JavascriptInterface
        public String location() {
            try {
                if (!has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    return "";
                }
                LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                Location best = null;
                for (String p : lm.getProviders(true)) {
                    Location l = lm.getLastKnownLocation(p);
                    if (l != null && (best == null || l.getAccuracy() < best.getAccuracy())) {
                        best = l;
                    }
                }
                if (best != null) {
                    return best.getLatitude() + "," + best.getLongitude();
                }
            } catch (Exception ignored) {
                // no location
            }
            return "";
        }
    }
}
