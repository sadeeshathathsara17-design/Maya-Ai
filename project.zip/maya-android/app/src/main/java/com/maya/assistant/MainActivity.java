package com.maya.assistant;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;


public class MainActivity extends Activity {
    private static final Map<String, String> ALIASES = new HashMap();
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile boolean visible = false;
    private volatile boolean wakePending = false;
    private WebView web;

    static {
        ALIASES.put("fb", "facebook");
        ALIASES.put("face book", "facebook");
        ALIASES.put("yt", "youtube");
        ALIASES.put("you tube", "youtube");
        ALIASES.put("whats app", "whatsapp");
        ALIASES.put("insta", "instagram");
        ALIASES.put("tik tok", "tiktok");
        ALIASES.put("google chrome", "chrome");
        ALIASES.put("play store", "play store");
    }

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(128);
        if (!siriMode()) {
            getWindow().setStatusBarColor(-16578540);
            getWindow().setNavigationBarColor(-16578540);
        }
        this.web = new WebView(this);
        this.web.setBackgroundColor(siriMode() ? 0 : -16578540);
        setContentView(this.web);
        WebSettings s = this.web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        this.web.setWebViewClient(new WebViewClient());
        this.web.setWebChromeClient(new WebChromeClient());
        this.web.addJavascriptInterface(new Bridge(), "Android");
        this.web.loadUrl("file:///android_asset/index.html");
        initTts();
        requestRuntimePermissions();
        handleWake(getIntent());
    }

    protected boolean siriMode() {
        return false;
    }

    private void handleWake(Intent intent) {
        if (intent == null || !intent.getBooleanExtra("wake", false)) {
            return;
        }
        intent.removeExtra("wake");
        this.wakePending = true;
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(2621440);
        }
        js("window.__wake && window.__wake()");
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleWake(intent);
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        this.visible = true;
        WakeService.setAppVisible(true);
        js("window.__onResume && window.__onResume()");
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        this.visible = false;
        if (this.recognizer != null) {
            this.recognizer.cancel();
        }
        WakeService.setAppVisible(false);
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        if (this.recognizer != null) {
            this.recognizer.destroy();
            this.recognizer = null;
        }
        if (this.tts != null) {
            this.tts.stop();
            this.tts.shutdown();
            this.tts = null;
        }
        super.onDestroy();
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        this.web.evaluateJavascript("(function(){var s=document.querySelector('.view.sub.on');if(s){s.classList.remove('on');return 'closed';}return 'none';})()", new ValueCallback<String>() { // from class: com.maya.assistant.MainActivity.1
            @Override // android.webkit.ValueCallback
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("closed")) {
                    MainActivity.super.onBackPressed();
                }
            }
        });
    }

    public void js(final String code) {
        runOnUiThread(new Runnable() { // from class: com.maya.assistant.MainActivity.2
            @Override // java.lang.Runnable
            public void run() {
                if (MainActivity.this.web != null) {
                    MainActivity.this.web.evaluateJavascript(code, null);
                }
            }
        });
    }

    public boolean has(String permission) {
        return checkSelfPermission(permission) == 0;
    }

    public void requestRuntimePermissions() {
        List<String> need = new ArrayList<>();
        String[] wanted = {"android.permission.RECORD_AUDIO", "android.permission.READ_CONTACTS", "android.permission.CALL_PHONE", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.POST_NOTIFICATIONS"};
        for (String p : wanted) {
            if ((!p.equals("android.permission.POST_NOTIFICATIONS") || Build.VERSION.SDK_INT >= 33) && !has(p)) {
                need.add(p);
            }
        }
        if (!need.isEmpty()) {
            requestPermissions((String[]) need.toArray(new String[0]), 1);
        }
    }

    private void initTts() {
        this.tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() { // from class: com.maya.assistant.MainActivity.3
            @Override // android.speech.tts.TextToSpeech.OnInitListener
            public void onInit(int status) {
                MainActivity.this.ttsReady = status == 0;
                if (MainActivity.this.ttsReady && MainActivity.this.tts != null) {
                    MainActivity.this.tts.setOnUtteranceProgressListener(new UtteranceProgressListener() { // from class: com.maya.assistant.MainActivity.3.1
                        @Override // android.speech.tts.UtteranceProgressListener
                        public void onStart(String utteranceId) {
                        }

                        @Override // android.speech.tts.UtteranceProgressListener
                        public void onDone(String utteranceId) {
                            MainActivity.this.js("window.__onSpeakDone && window.__onSpeakDone()");
                        }

                        @Override // android.speech.tts.UtteranceProgressListener
                        public void onError(String utteranceId) {
                            MainActivity.this.js("window.__onSpeakDone && window.__onSpeakDone()");
                        }
                    });
                }
            }
        });
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N} ]", "").trim();
    }

    public ResolveInfo findApp(String name) {
        String q = norm(name);
        if (q.isEmpty()) {
            return null;
        }
        String alias = ALIASES.get(q);
        if (alias != null) {
            q = alias;
        }
        PackageManager pm = getPackageManager();
        Intent main = new Intent("android.intent.action.MAIN");
        main.addCategory("android.intent.category.LAUNCHER");
        List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
        ResolveInfo exact = null;
        ResolveInfo starts = null;
        ResolveInfo contains = null;
        String compact = q.replace(" ", "");
        Iterator<ResolveInfo> it = list.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            ResolveInfo ri = it.next();
            String label = norm(String.valueOf(ri.loadLabel(pm)));
            String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
            if (label.equals(q)) {
                exact = ri;
                break;
            }
            if (starts == null && label.startsWith(q)) {
                starts = ri;
            }
            if (contains == null && (label.contains(q) || pkg.contains(compact))) {
                contains = ri;
            }
        }
        if (exact != null) {
            return exact;
        }
        return starts != null ? starts : contains;
    }

    public static String readAll(InputStream is) throws IOException {
        if (is == null) {
            return "";
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        while (true) {
            String line = r.readLine();
            if (line != null) {
                sb.append(line).append('\n');
            } else {
                r.close();
                return sb.toString();
            }
        }
    }

    public void launch(Intent i) {
        i.addFlags(268435456);
        try {
            startActivity(i);
        } catch (Exception e) {
        }
    }

    public void askGemini(String id, String key, String system, String user) {
        String lastError;
        String str;
        byte[] payload;
        int code;
        boolean ok;
        InputStream inputStream;
        String resp;
        String str2 = "text";
        String[] models = {"gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash", "gemini-2.5-flash-lite"};
        try {
            JSONObject body = new JSONObject();
            try {
                body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
                body.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", new JSONArray().put(new JSONObject().put("text", user)))));
                body.put("generationConfig", new JSONObject().put("maxOutputTokens", 900));
                byte[] payload2 = body.toString().getBytes("UTF-8");
                lastError = "Gemini unavailable";
                int attempt = 0;
                for (int i = 2; attempt < models.length * i; i = 2) {
                    try {
                        String m = models[attempt % models.length];
                        try {
                            HttpURLConnection c = (HttpURLConnection) new URL("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent").openConnection();
                            c.setRequestMethod("POST");
                            c.setConnectTimeout(15000);
                            c.setReadTimeout(60000);
                            try {
                                c.setDoOutput(true);
                                c.setRequestProperty("content-type", "application/json");
                                try {
                                    try {
                                        c.setRequestProperty("x-goog-api-key", key);
                                        OutputStream os = c.getOutputStream();
                                        os.write(payload2);
                                        os.close();
                                        code = c.getResponseCode();
                                        payload = payload2;
                                        ok = code >= 200 && code < 300;
                                        if (ok) {
                                            try {
                                                inputStream = c.getInputStream();
                                            } catch (IOException e) {
                                                e = e;
                                                str = str2;
                                            }
                                        } else {
                                            inputStream = c.getErrorStream();
                                        }
                                        resp = readAll(inputStream);
                                    } catch (IOException e2) {
                                        e = e2;
                                        str = str2;
                                        payload = payload2;
                                        lastError = String.valueOf(e.getMessage());
                                        attempt++;
                                        payload2 = payload;
                                        str2 = str;
                                    }
                                } catch (Exception e3) {
                                    e = e3;
                                    lastError = String.valueOf(e.getMessage());
                                    js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote(lastError) + ")");
                                }
                            } catch (IOException e4) {
                                e = e4;
                                str = str2;
                                payload = payload2;
                            }
                        } catch (IOException e5) {
                            e = e5;
                        }
                        if (ok) {
                            String text = new JSONObject(resp).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString(str2);
                            str = str2;
                            js("window.__onAsk(" + JSONObject.quote(id) + ",true," + JSONObject.quote(text) + ")");
                            return;
                        }
                        str = str2;
                        String detail = "";
                        try {
                            try {
                                detail = new JSONObject(resp).getJSONObject("error").getString("message");
                            } catch (IOException e6) {
                                e = e6;
                            }
                        } catch (Exception e7) {
                        }
                        String lastError2 = "Gemini error " + code + " (" + m + "): " + detail;
                        if (code == 400 || code == 401 || code == 403) {
                            lastError = lastError2;
                            break;
                        }
                        try {
                            try {
                                if (attempt >= models.length - 1) {
                                    try {
                                        Thread.sleep(1500L);
                                    } catch (IOException e8) {
                                        e = e8;
                                        lastError = String.valueOf(e.getMessage());
                                        attempt++;
                                        payload2 = payload;
                                        str2 = str;
                                    }
                                }
                                lastError = lastError2;
                            } catch (IOException e9) {
                                e = e9;
                            }
                            attempt++;
                            payload2 = payload;
                            str2 = str;
                        } catch (Exception e10) {
                            e = e10;
                            lastError = String.valueOf(e.getMessage());
                            js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote(lastError) + ")");
                        }
                        e = e6;
                        lastError = String.valueOf(e.getMessage());
                        attempt++;
                        payload2 = payload;
                        str2 = str;
                    } catch (Exception e11) {
                        e = e11;
                    }
                }
            } catch (Exception e12) {
                e = e12;
            }
        } catch (Exception e13) {
            e = e13;
        }
        js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote(lastError) + ")");
    }


    public class Bridge {
        public Bridge() {
        }

        @JavascriptInterface
        public String info() {
            return "{\"native\":true,\"sdk\":" + Build.VERSION.SDK_INT + "}";
        }

        @JavascriptInterface
        public void listen(final String lang) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.maya.assistant.MainActivity.Bridge.1
                @Override // java.lang.Runnable
                public void run() {
                    if (!MainActivity.this.visible) {
                        MainActivity.this.js("window.__onSpeechError && window.__onSpeechError(100)");
                        return;
                    }
                    if (!MainActivity.this.has("android.permission.RECORD_AUDIO")) {
                        MainActivity.this.js("window.__onSpeechError && window.__onSpeechError(9)");
                        MainActivity.this.requestRuntimePermissions();
                        return;
                    }
                    if (!SpeechRecognizer.isRecognitionAvailable(MainActivity.this)) {
                        MainActivity.this.js("window.__onSpeechError && window.__onSpeechError(5)");
                        return;
                    }
                    if (MainActivity.this.recognizer == null) {
                        MainActivity.this.recognizer = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
                        MainActivity.this.recognizer.setRecognitionListener(new RecognitionListener() { // from class: com.maya.assistant.MainActivity.Bridge.1.1
                            @Override // android.speech.RecognitionListener
                            public void onReadyForSpeech(Bundle params) {
                            }

                            @Override // android.speech.RecognitionListener
                            public void onBeginningOfSpeech() {
                            }

                            @Override // android.speech.RecognitionListener
                            public void onRmsChanged(float rmsdB) {
                            }

                            @Override // android.speech.RecognitionListener
                            public void onBufferReceived(byte[] buffer) {
                            }

                            @Override // android.speech.RecognitionListener
                            public void onEndOfSpeech() {
                            }

                            @Override // android.speech.RecognitionListener
                            public void onError(int error) {
                                MainActivity.this.js("window.__onSpeechError && window.__onSpeechError(" + error + ")");
                            }

                            @Override // android.speech.RecognitionListener
                            public void onResults(Bundle results) {
                                ArrayList<String> list = results.getStringArrayList("results_recognition");
                                if (list != null && !list.isEmpty()) {
                                    MainActivity.this.js("window.__onSpeech && window.__onSpeech(" + JSONObject.quote(list.get(0)) + ")");
                                } else {
                                    MainActivity.this.js("window.__onSpeechError && window.__onSpeechError(7)");
                                }
                            }

                            @Override // android.speech.RecognitionListener
                            public void onPartialResults(Bundle partialResults) {
                            }

                            @Override // android.speech.RecognitionListener
                            public void onEvent(int eventType, Bundle params) {
                            }
                        });
                    }
                    Intent i = new Intent("android.speech.action.RECOGNIZE_SPEECH");
                    i.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
                    i.putExtra("android.speech.extra.LANGUAGE", lang);
                    i.putExtra("android.speech.extra.PARTIAL_RESULTS", false);
                    i.putExtra("android.speech.extra.MAX_RESULTS", 1);
                    i.putExtra("calling_package", MainActivity.this.getPackageName());
                    MainActivity.this.recognizer.cancel();
                    MainActivity.this.recognizer.startListening(i);
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.maya.assistant.MainActivity.Bridge.2
                @Override // java.lang.Runnable
                public void run() {
                    if (MainActivity.this.recognizer != null) {
                        MainActivity.this.recognizer.cancel();
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean hasSinhalaVoice() {
            try {
                if (!MainActivity.this.ttsReady || MainActivity.this.tts == null) {
                    return false;
                }
                return MainActivity.this.tts.isLanguageAvailable(new Locale("si", "LK")) >= 0;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void speak(final String text, final String langTag) {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.maya.assistant.MainActivity.Bridge.3
                @Override // java.lang.Runnable
                public void run() {
                    if (!MainActivity.this.ttsReady || MainActivity.this.tts == null) {
                        MainActivity.this.js("window.__onSpeakDone && window.__onSpeakDone()");
                        return;
                    }
                    try {
                        MainActivity.this.tts.setLanguage(Locale.forLanguageTag(langTag));
                    } catch (Exception e) {
                    }
                    int r = MainActivity.this.tts.speak(text, 0, new Bundle(), WakeService.PREFS);
                    if (r != 0) {
                        MainActivity.this.js("window.__onSpeakDone && window.__onSpeakDone()");
                    }
                }
            });
        }

        @JavascriptInterface
        public void stopSpeaking() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.maya.assistant.MainActivity.Bridge.4
                @Override // java.lang.Runnable
                public void run() {
                    if (MainActivity.this.tts != null) {
                        MainActivity.this.tts.stop();
                    }
                }
            });
        }

        @JavascriptInterface
        public void ask(final String id, final String key, final String model, final String system, final String user) {
            new Thread(new Runnable() { // from class: com.maya.assistant.MainActivity.Bridge.5
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        if (key != null && !key.startsWith("sk-ant")) {
                            MainActivity.this.askGemini(id, key, system, user);
                            return;
                        }
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("model", model);
                        jSONObject.put("max_tokens", 900);
                        jSONObject.put("system", system);
                        JSONArray msgs = new JSONArray();
                        JSONObject m = new JSONObject();
                        m.put("role", "user");
                        m.put("content", user);
                        msgs.put(m);
                        jSONObject.put("messages", msgs);
                        HttpURLConnection c = (HttpURLConnection) new URL("https://api.anthropic.com/v1/messages").openConnection();
                        c.setRequestMethod("POST");
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(60000);
                        boolean ok = true;
                        c.setDoOutput(true);
                        c.setRequestProperty("content-type", "application/json");
                        c.setRequestProperty("x-api-key", key);
                        c.setRequestProperty("anthropic-version", "2023-06-01");
                        OutputStream os = c.getOutputStream();
                        os.write(jSONObject.toString().getBytes("UTF-8"));
                        os.close();
                        int code = c.getResponseCode();
                        if (code < 200 || code >= 300) {
                            ok = false;
                        }
                        String resp = MainActivity.readAll(ok ? c.getInputStream() : c.getErrorStream());
                        if (ok) {
                            String text = new JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text");
                            MainActivity.this.js("window.__onAsk(" + JSONObject.quote(id) + ",true," + JSONObject.quote(text) + ")");
                        } else {
                            String detail = "";
                            try {
                                detail = new JSONObject(resp).getJSONObject("error").getString("message");
                            } catch (Exception e) {
                            }
                            MainActivity.this.js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote("API error " + code + ": " + detail) + ")");
                        }
                    } catch (Exception e2) {
                        MainActivity.this.js("window.__onAsk(" + JSONObject.quote(id) + ",false," + JSONObject.quote(String.valueOf(e2.getMessage())) + ")");
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public String startWake(String unused) {
            try {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    MainActivity.this.launch(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + MainActivity.this.getPackageName())));
                    return "overlay";
                }
                MainActivity.this.getSharedPreferences(WakeService.PREFS, 0).edit().putBoolean(WakeService.PREF_ON, true).apply();
                Intent svc = new Intent(MainActivity.this, (Class<?>) WakeService.class);
                MainActivity.this.startForegroundService(svc);
                return "ok";
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public boolean isSiri() {
            return MainActivity.this.siriMode();
        }

        @JavascriptInterface
        public void closeSiri() {
            if (MainActivity.this.siriMode()) {
                MainActivity.this.runOnUiThread(new Runnable() { // from class: com.maya.assistant.MainActivity.Bridge.6
                    @Override // java.lang.Runnable
                    public void run() {
                        MainActivity.this.finish();
                    }
                });
            }
        }

        @JavascriptInterface
        public String wakeStatus() {
            return WakeService.status;
        }

        @JavascriptInterface
        public void stopWake() {
            MainActivity.this.getSharedPreferences(WakeService.PREFS, 0).edit().putBoolean(WakeService.PREF_ON, false).apply();
            MainActivity.this.stopService(new Intent(MainActivity.this, (Class<?>) WakeService.class));
        }

        @JavascriptInterface
        public boolean wakeOn() {
            return WakeService.isRunning();
        }

        @JavascriptInterface
        public boolean consumeWake() {
            boolean w = MainActivity.this.wakePending;
            MainActivity.this.wakePending = false;
            return w;
        }

        @JavascriptInterface
        public void openBatterySettings() {
            MainActivity.this.launch(new Intent("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"));
        }

        @JavascriptInterface
        public String openApp(String name) {
            Intent i;
            ResolveInfo ri = MainActivity.this.findApp(name);
            if (ri == null || (i = MainActivity.this.getPackageManager().getLaunchIntentForPackage(ri.activityInfo.packageName)) == null) {
                return "";
            }
            MainActivity.this.launch(i);
            return String.valueOf(ri.loadLabel(MainActivity.this.getPackageManager()));
        }

        @JavascriptInterface
        public String closeApp(String name) {
            if (name == null || name.trim().isEmpty()) {
                return MayaAccessibilityService.perform("close_current", "");
            }
            ResolveInfo ri = MainActivity.this.findApp(name);
            if (ri == null) {
                return "notfound";
            }
            try {
                ActivityManager am = (ActivityManager) MainActivity.this.getSystemService("activity");
                am.killBackgroundProcesses(ri.activityInfo.packageName);
                return "ok";
            } catch (Exception e) {
                return "ok";
            }
        }

        @JavascriptInterface
        public String closeAllApps() {
            return MayaAccessibilityService.perform("close_all", "");
        }

        @JavascriptInterface
        public String phone(String action, String arg) {
            return MayaAccessibilityService.perform(action, arg);
        }

        @JavascriptInterface
        public boolean a11yEnabled() {
            return MayaAccessibilityService.instance != null;
        }

        @JavascriptInterface
        public void openA11ySettings() {
            MainActivity.this.launch(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
        }

        @JavascriptInterface
        public String contact(String names) {
            int i;
            if (names == null || !MainActivity.this.has("android.permission.READ_CONTACTS")) {
                return "";
            }
            char c = 0;
            for (String n : names.split("\\|")) {
                String q = n.trim();
                if (!q.isEmpty()) {
                    Cursor c2 = null;
                    try {
                        try {
                            ContentResolver contentResolver = MainActivity.this.getContentResolver();
                            Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
                            String[] strArr = new String[1];
                            strArr[c] = "data1";
                            String[] strArr2 = new String[1];
                            try {
                            } catch (Exception e) {
                                c = 0;
                            }
                            try {
                                strArr2[0] = "%" + q + "%";
                                c2 = contentResolver.query(uri, strArr, "display_name LIKE ?", strArr2, null);
                            } catch (Exception e2) {
                                c = 0;
                                i = c2 == null ? i + 1 : 0;
                                c2.close();
                            }
                        } finally {
                            if (c2 != null) {
                                c2.close();
                            }
                        }
                    } catch (Exception e3) {
                    }
                    if (c2 != null && c2.moveToFirst()) {
                        c = 0;
                        return c2.getString(0);
                    }
                    c = 0;
                    if (c2 == null) {
                    }
                    c2.close();
                }
            }
            return "";
        }

        @JavascriptInterface
        public void call(String number) {
            Uri uri = Uri.parse("tel:" + Uri.encode(number));
            MainActivity.this.launch(new Intent(MainActivity.this.has("android.permission.CALL_PHONE") ? "android.intent.action.CALL" : "android.intent.action.DIAL", uri));
        }

        @JavascriptInterface
        public void sms(String number, String text) {
            Intent i = new Intent("android.intent.action.SENDTO", Uri.parse("smsto:" + Uri.encode(number)));
            i.putExtra("sms_body", text);
            MainActivity.this.launch(i);
        }

        @JavascriptInterface
        public void alarm(int hour, int minute, String label) {
            Intent i = new Intent("android.intent.action.SET_ALARM");
            i.putExtra("android.intent.extra.alarm.HOUR", hour);
            i.putExtra("android.intent.extra.alarm.MINUTES", minute);
            i.putExtra("android.intent.extra.alarm.MESSAGE", label == null ? "Maya" : label);
            i.putExtra("android.intent.extra.alarm.SKIP_UI", true);
            MainActivity.this.launch(i);
        }

        @JavascriptInterface
        public void timer(int seconds) {
            Intent i = new Intent("android.intent.action.SET_TIMER");
            i.putExtra("android.intent.extra.alarm.LENGTH", seconds);
            i.putExtra("android.intent.extra.alarm.SKIP_UI", true);
            MainActivity.this.launch(i);
        }

        @JavascriptInterface
        public void openUrl(String url) {
            MainActivity.this.launch(new Intent("android.intent.action.VIEW", Uri.parse(url)));
        }

        @JavascriptInterface
        public String location() {
            if (!MainActivity.this.has("android.permission.ACCESS_COARSE_LOCATION")) {
                return "";
            }
            LocationManager lm = (LocationManager) MainActivity.this.getSystemService("location");
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getAccuracy() < best.getAccuracy())) {
                    best = l;
                }
            }
            if (best != null) {
                return best.getLatitude() + "," + best.getLongitude();
            }
            return "";
        }
    }
}
